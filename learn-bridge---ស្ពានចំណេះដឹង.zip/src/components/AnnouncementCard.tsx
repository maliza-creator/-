import React from 'react';
import { Heart, MessageCircle, Share2, ArrowRight } from 'lucide-react';
import { Announcement } from '../types';

interface AnnouncementCardProps {
  announcement: Announcement;
  onLike: (id: string) => void;
  onOpenTarget: (announcement: Announcement) => void;
}

export const AnnouncementCard: React.FC<AnnouncementCardProps> = ({
  announcement,
  onLike,
  onOpenTarget,
}) => {
  const getTypeBadge = () => {
    switch (announcement.type) {
      case 'mock_exam':
        return {
          label: '📢 វិញ្ញាសាសាកល្បង',
          className: 'bg-red-50 text-red-700 border-red-200',
        };
      case 'new_lesson':
        return {
          label: '📘 មេរៀនថ្មី',
          className: 'bg-blue-50 text-blue-700 border-blue-200',
        };
      case 'quiz':
        return {
          label: '📝 តេស្តប្រឡង',
          className: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        };
      case 'exercise':
        return {
          label: '🔥 លំហាត់អនុវត្ត',
          className: 'bg-orange-50 text-orange-700 border-orange-200',
        };
      default:
        return {
          label: '📌 ប្រកាស',
          className: 'bg-slate-100 text-slate-700 border-slate-200',
        };
    }
  };

  const badge = getTypeBadge();

  return (
    <article className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-sm hover:shadow-md transition-all">
      {/* Author Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <img
            src={announcement.teacherAvatar}
            alt={announcement.teacherName}
            className="w-9 h-9 rounded-full object-cover ring-2 ring-blue-100"
          />
          <div>
            <h3 className="text-xs font-bold text-slate-800 leading-none">
              {announcement.teacherName}
            </h3>
            <span className="text-[10px] text-slate-400 mt-0.5 block">
              {announcement.timestamp} • {announcement.subjectNameKh || 'ទូទៅ'}
            </span>
          </div>
        </div>

        <span
          className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${badge.className}`}
        >
          {badge.label}
        </span>
      </div>

      {/* Post Title & Content */}
      <h4 className="text-sm font-bold text-slate-900 mb-1.5 leading-snug">
        {announcement.titleKh}
      </h4>
      <p className="text-xs text-slate-600 leading-relaxed mb-3">
        {announcement.contentKh}
      </p>

      {/* Interactive Action Banner CTA */}
      <div className="mb-3 bg-gradient-to-r from-blue-50 to-indigo-50/70 p-3 rounded-xl border border-blue-100/80 flex items-center justify-between">
        <span className="text-xs font-bold text-blue-900">
          ចូលរួមសិក្សា ឬធ្វើតេស្តឥឡូវនេះ
        </span>
        <button
          onClick={() => onOpenTarget(announcement)}
          className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-transform active:scale-95 shadow-xs"
        >
          <span>បើកមើល</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Footer Like / Comment Social Counter */}
      <div className="flex items-center justify-between pt-2.5 border-t border-slate-100 text-xs text-slate-500">
        <div className="flex items-center gap-4">
          <button
            onClick={() => onLike(announcement.id)}
            className={`flex items-center gap-1.5 transition-colors ${
              announcement.isLiked ? 'text-red-500 font-bold' : 'hover:text-red-500'
            }`}
          >
            <Heart
              className={`w-4 h-4 ${announcement.isLiked ? 'fill-red-500 text-red-500' : ''}`}
            />
            <span>{announcement.likes}</span>
          </button>

          <button
            onClick={() => onOpenTarget(announcement)}
            className="flex items-center gap-1.5 hover:text-blue-600 transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{announcement.commentsCount} មតិ</span>
          </button>
        </div>

        <button className="p-1 hover:text-slate-800 transition-colors" title="ចែករំលែក">
          <Share2 className="w-4 h-4" />
        </button>
      </div>
    </article>
  );
};
