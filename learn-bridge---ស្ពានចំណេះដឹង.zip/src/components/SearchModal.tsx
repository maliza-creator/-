import React, { useState } from 'react';
import { Subject, Lesson, MockExam } from '../types';
import { Search, X, BookOpen, Clock, ChevronRight } from 'lucide-react';

interface SearchModalProps {
  subjects: Subject[];
  lessons: Lesson[];
  mockExams: MockExam[];
  onClose: () => void;
  onSelectLesson: (lesson: Lesson) => void;
  onSelectSubject: (subject: Subject) => void;
  onSelectMockExam: (exam: MockExam) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  subjects = [],
  lessons = [],
  mockExams = [],
  onClose,
  onSelectLesson,
  onSelectSubject,
  onSelectMockExam,
}) => {
  const [query, setQuery] = useState('');

  const safeLessons = lessons || [];
  const safeSubjects = subjects || [];
  const safeExams = mockExams || [];

  const filteredLessons = query.trim()
    ? safeLessons.filter(
        (l) =>
          l.titleKh?.toLowerCase().includes(query.toLowerCase()) ||
          l.titleEn?.toLowerCase().includes(query.toLowerCase()) ||
          l.summaryKh?.toLowerCase().includes(query.toLowerCase())
      )
    : safeLessons.slice(0, 4);

  const filteredSubjects = query.trim()
    ? safeSubjects.filter(
        (s) =>
          s.nameKh?.toLowerCase().includes(query.toLowerCase()) ||
          s.nameEn?.toLowerCase().includes(query.toLowerCase())
      )
    : safeSubjects;

  const filteredExams = query.trim()
    ? safeExams.filter(
        (m) =>
          m.titleKh?.toLowerCase().includes(query.toLowerCase()) ||
          m.subjectNameKh?.toLowerCase().includes(query.toLowerCase())
      )
    : safeExams;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-start justify-center p-4 pt-12 animate-fade-in">
      <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Header */}
        <div className="p-3 border-b border-slate-100 flex items-center gap-2">
          <Search className="w-5 h-5 text-blue-600 ml-2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ស្វែងរកមេរៀន មុខវិជ្ជា ឬវិញ្ញាសាបាក់ឌុប..."
            autoFocus
            className="flex-1 py-2 bg-transparent text-xs text-slate-800 font-medium focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results Body */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* Lessons */}
          <div>
            <h4 className="font-bold text-slate-400 uppercase tracking-wider text-[10px] mb-2">
              មេរៀន ({filteredLessons.length})
            </h4>
            <div className="space-y-1.5">
              {filteredLessons.map((les) => (
                <button
                  key={les.id}
                  onClick={() => {
                    onClose();
                    onSelectLesson(les);
                  }}
                  className="w-full text-left p-2.5 rounded-xl hover:bg-blue-50 transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-blue-600" />
                    <div>
                      <span className="font-bold text-slate-800 group-hover:text-blue-700 block">
                        {les.chapterNumber}. {les.titleKh}
                      </span>
                      <span className="text-[10px] text-slate-400">{les.summaryKh}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-300" />
                </button>
              ))}
            </div>
          </div>

          {/* Subjects */}
          <div>
            <h4 className="font-bold text-slate-400 uppercase tracking-wider text-[10px] mb-2">
              មុខវិជ្ជា ({filteredSubjects.length})
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {filteredSubjects.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => {
                    onClose();
                    onSelectSubject(sub);
                  }}
                  className="p-2.5 bg-slate-50 hover:bg-blue-50 rounded-xl border border-slate-100 text-left transition-colors"
                >
                  <span className="font-bold text-slate-800 block">{sub.nameKh}</span>
                  <span className="text-[10px] text-slate-400">{sub.chaptersCount} មេរៀន</span>
                </button>
              ))}
            </div>
          </div>

          {/* Mock Exams */}
          <div>
            <h4 className="font-bold text-slate-400 uppercase tracking-wider text-[10px] mb-2">
              វិញ្ញាសាសាកល្បង ({filteredExams.length})
            </h4>
            <div className="space-y-1.5">
              {filteredExams.map((exam) => (
                <button
                  key={exam.id}
                  onClick={() => {
                    onClose();
                    onSelectMockExam(exam);
                  }}
                  className="w-full p-2.5 bg-amber-50/60 hover:bg-amber-100 rounded-xl border border-amber-200/80 text-left transition-colors flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-amber-950 block">{exam.titleKh}</span>
                    <span className="text-[10px] text-amber-800">
                      {exam.durationMinutes} នាទី • {exam.questions?.length || 0} សំណួរ
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-amber-600" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
