import React from 'react';
import { Home, BookOpen, Bot, Users, User } from 'lucide-react';

export type TabType = 'home' | 'subjects' | 'ai_tutor' | 'study_club' | 'profile';

interface BottomNavProps {
  activeTab: TabType;
  onTabChange?: (tab: TabType) => void;
  onChangeTab?: (tab: TabType) => void;
  unreadNotificationsCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  onChangeTab,
}) => {
  const handleSelect = (tab: TabType) => {
    if (onTabChange) onTabChange(tab);
    if (onChangeTab) onChangeTab(tab);
  };

  const navItems = [
    { id: 'home' as TabType, labelKh: 'ទំព័រដើម', icon: Home },
    { id: 'subjects' as TabType, labelKh: 'មុខវិជ្ជា', icon: BookOpen },
    { id: 'ai_tutor' as TabType, labelKh: 'AI Tutor', icon: Bot, isSpecial: true },
    { id: 'study_club' as TabType, labelKh: 'ក្លឹបសិក្សា', icon: Users },
    { id: 'profile' as TabType, labelKh: 'គណនី', icon: User },
  ];

  return (
    <nav className="sticky bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 shadow-sm">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          if (item.isSpecial) {
            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`relative flex flex-col items-center justify-center -mt-5 px-3 transition-transform active:scale-95 ${
                  isActive ? 'scale-105' : ''
                }`}
                aria-label={item.labelKh}
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg shadow-blue-200/80 transition-all duration-300 ${
                    isActive
                      ? 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white ring-4 ring-blue-100'
                      : 'bg-gradient-to-br from-blue-600 via-indigo-600 to-blue-700 text-white hover:opacity-95'
                  }`}
                >
                  <Icon className="w-6 h-6 text-amber-300 animate-pulse-subtle" />
                </div>
                <span
                  className={`text-[11px] font-semibold mt-1 transition-colors ${
                    isActive ? 'text-blue-700 font-extrabold' : 'text-slate-600'
                  }`}
                >
                  {item.labelKh}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all duration-200 ${
                isActive ? 'text-blue-700' : 'text-slate-500 hover:text-slate-800'
              }`}
              aria-label={item.labelKh}
            >
              <div
                className={`px-3 py-1 rounded-full transition-all duration-200 ${
                  isActive ? 'bg-blue-50 text-blue-700 font-bold' : ''
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              </div>
              <span className={`text-[10px] mt-0.5 whitespace-nowrap ${isActive ? 'font-bold text-blue-900' : 'font-medium'}`}>
                {item.labelKh}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
