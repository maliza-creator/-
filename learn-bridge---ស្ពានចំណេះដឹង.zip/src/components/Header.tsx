import React from 'react';
import { Bell, Search, Sparkles, UserCheck, ShieldCheck } from 'lucide-react';
import { User, UserRole } from '../types';
import { initialStudentUser } from '../data/mockData';

interface HeaderProps {
  currentUser?: User;
  user?: User;
  onToggleRole?: (newRole?: UserRole) => void;
  onOpenNotifications: () => void;
  onOpenSearch?: () => void;
  unreadCount?: number;
  unreadNotificationsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  user,
  onToggleRole,
  onOpenNotifications,
  onOpenSearch,
  unreadCount,
  unreadNotificationsCount,
}) => {
  const activeUser = currentUser || user || initialStudentUser;
  const isStudent = activeUser?.role === 'student';
  const displayUnread = unreadNotificationsCount ?? unreadCount ?? 2;

  const handleRoleToggle = () => {
    if (onToggleRole) {
      onToggleRole(isStudent ? 'teacher' : 'student');
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 py-3 shadow-xs">
      <div className="flex items-center justify-between max-w-md mx-auto">
        {/* Brand & User Info */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <img
              src={activeUser.avatar}
              alt={activeUser.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/30 shadow-xs"
            />
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white ${
                isStudent ? 'bg-emerald-500' : 'bg-orange-500'
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold text-slate-800 leading-tight">
                {activeUser.name}
              </h1>
              <span
                className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-full inline-flex items-center gap-0.5 ${
                  isStudent
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'bg-orange-50 text-orange-700 border border-orange-200'
                }`}
              >
                {isStudent ? (
                  <>
                    <UserCheck className="w-2.5 h-2.5" /> សិស្ស
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-2.5 h-2.5" /> គ្រូ
                  </>
                )}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 truncate max-w-[170px]">
              {activeUser.school}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Quick Search */}
          {onOpenSearch && (
            <button
              onClick={onOpenSearch}
              className="p-2 rounded-full text-slate-600 hover:bg-slate-100 transition-colors"
              title="ស្វែងរក"
              aria-label="ស្វែងរក"
            >
              <Search className="w-5 h-5" />
            </button>
          )}

          {/* Role Switcher */}
          <button
            onClick={handleRoleToggle}
            className="flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-all active:scale-95"
            title="ប្តូរតួនាទី (សិស្ស / គ្រូ)"
          >
            <Sparkles className="w-3.5 h-3.5 text-orange-500" />
            <span>{isStudent ? 'ប្តូរជាគ្រូ' : 'ប្តូរជាសិស្ស'}</span>
          </button>

          {/* Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-full text-slate-600 hover:bg-slate-100 transition-colors"
            title="ការជូនដំណឹង"
            aria-label="ការជូនដំណឹង"
          >
            <Bell className="w-5 h-5" />
            {displayUnread > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center animate-bounce">
                {displayUnread}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
