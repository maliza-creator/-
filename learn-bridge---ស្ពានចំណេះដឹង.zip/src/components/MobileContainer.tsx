import React, { useState } from 'react';
import { Smartphone, Monitor, Wifi, Battery, Signal } from 'lucide-react';

interface MobileContainerProps {
  children: React.ReactNode;
}

export const MobileContainer: React.FC<MobileContainerProps> = ({ children }) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);

  const currentTime = '09:41';

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-start sm:py-6 sm:px-4 font-sans text-slate-800">
      {/* Top Bar Switcher Control */}
      <div className="w-full max-w-md px-4 py-2 flex items-center justify-between text-slate-300 text-xs mb-2">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-slate-200">Learn Bridge App (ស្ពានចំណេះដឹង)</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all text-xs font-medium"
          >
            {isPhoneFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-blue-400" /> ពង្រីកពេញអេក្រង់
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-blue-400" /> ទម្រង់ទូរស័ព្ទ
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container Wrapper */}
      <div
        className={`w-full transition-all duration-300 flex flex-col ${
          isPhoneFrame
            ? 'max-w-[420px] bg-[#F1F5F9] min-h-[850px] max-h-[92vh] rounded-[42px] border-[10px] border-slate-800 shadow-2xl shadow-blue-950/40 overflow-hidden relative'
            : 'max-w-2xl bg-[#F1F5F9] min-h-screen rounded-none sm:rounded-3xl shadow-xl overflow-hidden relative'
        }`}
      >
        {/* Phone Top Speaker Notch Bar (Only in Phone Frame) */}
        {isPhoneFrame && (
          <div className="bg-white pt-2 px-6 pb-1 flex items-center justify-between text-slate-800 text-xs font-bold select-none border-b border-slate-200/80 z-50">
            <span>{currentTime}</span>
            {/* Dynamic Notch */}
            <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5 text-slate-700">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4" />
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto flex flex-col bg-[#F1F5F9] relative">
          {children}
        </div>
      </div>
    </div>
  );
};
