import React from 'react';
import { X, Bell, CheckCircle2, MessageSquare, Flame, BookOpen } from 'lucide-react';
import { NotificationItem, Announcement } from '../types';

interface NotificationDrawerProps {
  isOpen?: boolean;
  onClose: () => void;
  notifications?: NotificationItem[];
  announcements?: Announcement[];
  onOpenAnnouncement?: (announcement: Announcement) => void;
  onMarkAllRead?: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  onClose,
  notifications = [],
  announcements = [],
  onOpenAnnouncement,
  onMarkAllRead,
}) => {
  const safeAnnouncements = announcements || [];
  const safeNotifications = notifications || [];

  const displayItems = safeAnnouncements.length > 0
    ? safeAnnouncements.map((a) => ({
        id: a.id,
        titleKh: a.titleKh,
        messageKh: a.contentKh,
        timestamp: a.timestamp,
        isRead: false,
        type: a.type === 'mock_exam' ? ('exam' as const) : ('lesson' as const),
        rawAnn: a,
      }))
    : safeNotifications.map((n) => ({
        id: n.id,
        titleKh: n.titleKh,
        messageKh: n.messageKh,
        timestamp: n.timestamp,
        isRead: n.isRead,
        type: n.type,
        rawAnn: null,
      }));

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-xs bg-white h-full shadow-2xl flex flex-col p-4 overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600 border border-blue-100">
              <Bell className="w-5 h-5" />
            </div>
            <h2 className="font-extrabold text-slate-800 text-sm">ការជូនដំណឹង (Notifications)</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mark All Read Button */}
        {onMarkAllRead && displayItems.some((n) => !n.isRead) && (
          <div className="flex justify-end mb-3">
            <button
              onClick={onMarkAllRead}
              className="text-[11px] font-bold text-blue-600 hover:underline flex items-center gap-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" /> អានទាំងអស់
            </button>
          </div>
        )}

        {/* List */}
        <div className="space-y-2.5 flex-1 overflow-y-auto">
          {displayItems.map((item) => (
            <div
              key={item.id}
              onClick={() => {
                if (item.rawAnn && onOpenAnnouncement) {
                  onOpenAnnouncement(item.rawAnn);
                }
              }}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                item.isRead
                  ? 'bg-slate-50/80 border-slate-200'
                  : 'bg-blue-50/60 border-blue-200 shadow-xs hover:border-blue-300'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <div className="p-1.5 rounded-xl bg-white shadow-xs border border-slate-200 mt-0.5">
                  <Bell className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-800 leading-snug">{item.titleKh}</h3>
                    {!item.isRead && <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />}
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 leading-relaxed line-clamp-2">
                    {item.messageKh}
                  </p>
                  <span className="text-[9px] text-slate-400 font-medium mt-1.5 block">
                    {item.timestamp}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-200 mt-auto">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-colors"
          >
            បិទ
          </button>
        </div>
      </div>
    </div>
  );
};
