/**
 * Learn Bridge - Types & Data Models
 * Grade 12 Cambodian BACII Educational Platform
 */

export type UserRole = 'student' | 'teacher';
export type StreamType = 'science' | 'social';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar: string;
  phone: string;
  email: string;
  school: string;
  grade: string;
  stream: StreamType;
  streakDays: number;
  completedLessons: number;
  completedQuizzes: number;
  averageScore: number;
  achievements: Badge[];
  weeklyHours: number[]; // Mon - Sun
}

export interface Badge {
  id: string;
  titleKh: string;
  descriptionKh: string;
  icon: string;
  unlockedAt?: string;
}

export interface Subject {
  id: string;
  nameKh: string;
  nameEn: string;
  stream: StreamType;
  icon: string;
  color: string;
  bgGradient: string;
  lessonsCount: number;
  exercisesCount: number;
  descriptionKh: string;
  chaptersCount: number;
}

export interface Lesson {
  id: string;
  subjectId: string;
  chapterNumber: number;
  titleKh: string;
  titleEn: string;
  summaryKh: string;
  explanationKh: string;
  formulas: string[];
  examplesKh: { question: string; solution: string }[];
  teacherNotes: string;
  durationMinutes: number;
  completed?: boolean;
}

export interface ExerciseOption {
  text: string;
  isCorrect: boolean;
}

export interface ExerciseQuestion {
  id: string;
  lessonId?: string;
  subjectId: string;
  questionKh: string;
  options: string[];
  correctIndex: number;
  explanationKh: string;
  hintKh: string;
}

export interface Quiz {
  id: string;
  subjectId: string;
  titleKh: string;
  timeLimitMinutes: number;
  questionsCount: number;
  questions: ExerciseQuestion[];
}

export interface MockExam {
  id: string;
  subjectId: string;
  subjectNameKh: string;
  titleKh: string;
  year: number;
  durationMinutes: number;
  totalScore: number;
  instructionsKh: string;
  questions: ExerciseQuestion[];
  teacherName: string;
}

export type AnnouncementType = 'mock_exam' | 'new_lesson' | 'quiz' | 'exercise' | 'teacher_post';

export interface Announcement {
  id: string;
  type: AnnouncementType;
  titleKh: string;
  contentKh: string;
  teacherName: string;
  teacherAvatar: string;
  timestamp: string;
  likes: number;
  commentsCount: number;
  targetId?: string;
  subjectNameKh?: string;
  isLiked?: boolean;
}

export interface ClubPost {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorRole: UserRole;
  content: string;
  timestamp: string;
  likes: number;
  comments: number;
}

export interface SharedFile {
  id: string;
  name: string;
  size: string;
  uploader: string;
  date: string;
  type: 'pdf' | 'doc' | 'img';
}

export interface StudyClub {
  id: string;
  nameKh: string;
  categoryKh: string;
  coverImg: string;
  avatar: string;
  membersCount: number;
  descriptionKh: string;
  creatorName: string;
  creatorRole: UserRole;
  posts: ClubPost[];
  files: SharedFile[];
  upcomingSession?: {
    title: string;
    date: string;
    time: string;
  };
}

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  imageUri?: string;
  isThinking?: boolean;
}

export interface NotificationItem {
  id: string;
  titleKh: string;
  messageKh: string;
  timestamp: string;
  isRead: boolean;
  type: 'reminder' | 'lesson' | 'announcement' | 'club' | 'exam';
}
