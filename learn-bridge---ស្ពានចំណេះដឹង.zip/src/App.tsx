import React, { useState } from 'react';
import {
  User,
  UserRole,
  Subject,
  Lesson,
  Announcement,
  MockExam,
  ExerciseQuestion,
} from './types';
import {
  initialStudentUser,
  initialTeacherUser,
  scienceSubjects,
  socialSubjects,
  mathLessons,
  initialAnnouncements,
  sampleMockExams,
} from './data/mockData';

import { MobileContainer } from './components/MobileContainer';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { NotificationDrawer } from './components/NotificationDrawer';
import { SearchModal } from './components/SearchModal';

import { SplashScreen } from './screens/SplashScreen';
import { RoleSelectionScreen } from './screens/RoleSelectionScreen';
import { AuthScreens } from './screens/AuthScreens';
import { HomeScreen } from './screens/HomeScreen';
import { SubjectsScreen } from './screens/SubjectsScreen';
import { SubjectDetailScreen } from './screens/SubjectDetailScreen';
import { LessonDetailScreen } from './screens/LessonDetailScreen';
import { ExerciseScreen } from './screens/ExerciseScreen';
import { QuizResultScreen } from './screens/QuizResultScreen';
import { MockExamScreen } from './screens/MockExamScreen';
import { AITutorScreen } from './screens/AITutorScreen';
import { StudyClubScreen } from './screens/StudyClubScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { TeacherDashboardScreen } from './screens/TeacherDashboardScreen';

type ScreenRoute =
  | 'splash'
  | 'role_selection'
  | 'auth'
  | 'main'
  | 'subject_detail'
  | 'lesson_detail'
  | 'exercise'
  | 'quiz_result'
  | 'mock_exam';

export function App() {
  // App Navigation & Session States
  const [currentRoute, setCurrentRoute] = useState<ScreenRoute>('splash');
  const [activeTab, setActiveTab] = useState<'home' | 'subjects' | 'ai_tutor' | 'study_club' | 'profile'>('home');
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');
  const [currentUser, setCurrentUser] = useState<User>(initialStudentUser);

  // App Content States
  const [announcements, setAnnouncements] = useState<Announcement[]>(initialAnnouncements);
  const [lessons, setLessons] = useState<Lesson[]>(mathLessons);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [activeMockExam, setActiveMockExam] = useState<MockExam>(sampleMockExams[0]);

  // Exercise & Quiz Evaluation States
  const [exerciseTitle, setExerciseTitle] = useState('លំហាត់អនុវត្តមេរៀន');
  const [exerciseQuestions, setExerciseQuestions] = useState<ExerciseQuestion[]>([]);
  const [quizScore, setQuizScore] = useState(0);
  const [quizTotal, setQuizTotal] = useState(0);
  const [quizAnswersHistory, setQuizAnswersHistory] = useState<any[]>([]);

  // Overlay Modals
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // User Handlers
  const handleSelectRole = (role: UserRole) => {
    setSelectedRole(role);
    setCurrentUser(role === 'student' ? initialStudentUser : initialTeacherUser);
    setCurrentRoute('auth');
  };

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    setCurrentRoute('main');
  };

  const handleRoleSwitchInHeader = (newRole: UserRole) => {
    setSelectedRole(newRole);
    setCurrentUser((prev) => ({
      ...prev,
      role: newRole,
    }));
  };

  const handleLikeAnnouncement = (id: string) => {
    setAnnouncements((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const isLiked = !a.isLiked;
          return {
            ...a,
            isLiked,
            likes: isLiked ? a.likes + 1 : a.likes - 1,
          };
        }
        return a;
      })
    );
  };

  const handleOpenAnnouncement = (ann: Announcement) => {
    if (ann.type === 'mock_exam') {
      setCurrentRoute('mock_exam');
    } else if (ann.type === 'new_lesson') {
      setSelectedLesson(lessons[0]);
      setCurrentRoute('lesson_detail');
    } else {
      setActiveTab('subjects');
      setCurrentRoute('main');
    }
  };

  const handleStartExerciseForLesson = (les: Lesson) => {
    setExerciseTitle(`លំហាត់អនុវត្ត - ${les.titleKh}`);
    setExerciseQuestions([
      {
        id: 'ex_1',
        questionKh: 'គណនាលីមីត lim (x -> 2) [ (x² - 4) / (x - 2) ]',
        options: ['A) 2', 'B) 4', 'C) 0', 'D) 8'],
        correctIndex: 1,
        explanationKh: 'ដោយបំបែកភាគយក (x-2)(x+2) ហើយសម្រួល (x-2) គេបាន lim (x+2) = 2+2 = 4',
        hintKh: 'ប្រើរូបមន្ត a² - b² = (a - b)(a + b)',
      },
      {
        id: 'ex_2',
        questionKh: 'គណនាលីមីត lim (x -> 0) [ sin(3x) / x ]',
        options: ['A) 1', 'B) 0', 'C) 3', 'D) ∞'],
        correctIndex: 2,
        explanationKh: 'ប្រើរូបមន្តគ្រឹះ lim (x->0) [ sin(ax) / x ] = a ដូច្នេះស្មើ 3',
        hintKh: 'គុណ និងចែកភាគបែងនឹង 3',
      },
    ]);
    setCurrentRoute('exercise');
  };

  const handleStartQuizForLesson = (les: Lesson) => {
    setExerciseTitle(`តេស្តប្រឡងសាកល្បង - ${les.titleKh}`);
    setExerciseQuestions([
      {
        id: 'qz_1',
        questionKh: 'គណនាលីមីត lim (x -> +∞) [ (2x² + 3x) / (x² - 1) ]',
        options: ['A) 2', 'B) 3', 'C) +∞', 'D) 0'],
        correctIndex: 0,
        explanationKh: 'ទាញ x² ជាកត្តារួមនៅភាគយក និងភាគបែង គេបានមេគុណ 2/1 = 2',
        hintKh: 'ទាញស្វ័យគុណធំបំផុតជាកត្តារួម',
      },
      {
        id: 'qz_2',
        questionKh: 'គណនាដេរីវេនៃអនុគមន៍ f(x) = x³ - 5x + 7',
        options: ['A) 3x² - 5', 'B) 3x²', 'C) 3x² + 5', 'D) x² - 5'],
        correctIndex: 0,
        explanationKh: 'រូបមន្ត (x^n)\' = n*x^(n-1) និង (ax)\' = a ដូច្នេះ (x³ - 5x + 7)\' = 3x² - 5',
        hintKh: 'ប្រើរូបមន្តដេរីវេនៃស្វ័យគុណ',
      },
    ]);
    setCurrentRoute('exercise');
  };

  const handleFinishExercise = (score: number, total: number, answersHistory: any[]) => {
    setQuizScore(score);
    setQuizTotal(total);
    setQuizAnswersHistory(answersHistory);
    setCurrentRoute('quiz_result');
  };

  const handleFinishMockExam = (result: any) => {
    setQuizScore(result.score);
    setQuizTotal(result.total);
    setQuizAnswersHistory(result.details);
    setCurrentRoute('quiz_result');
  };

  // Render current Screen view
  const renderCurrentScreen = () => {
    switch (currentRoute) {
      case 'splash':
        return <SplashScreen onStart={() => setCurrentRoute('role_selection')} />;

      case 'role_selection':
        return <RoleSelectionScreen onSelectRole={handleSelectRole} />;

      case 'auth':
        return (
          <AuthScreens
            selectedRole={selectedRole}
            onAuthSuccess={handleAuthSuccess}
            onBackToRole={() => setCurrentRoute('role_selection')}
          />
        );

      case 'subject_detail':
        return selectedSubject ? (
          <SubjectDetailScreen
            subject={selectedSubject}
            lessons={lessons}
            onBack={() => setCurrentRoute('main')}
            onSelectLesson={(les) => {
              setSelectedLesson(les);
              setCurrentRoute('lesson_detail');
            }}
          />
        ) : null;

      case 'lesson_detail':
        return selectedLesson ? (
          <LessonDetailScreen
            lesson={selectedLesson}
            onBack={() => setCurrentRoute('main')}
            onStartExercise={handleStartExerciseForLesson}
            onStartQuiz={handleStartQuizForLesson}
          />
        ) : null;

      case 'exercise':
        return (
          <ExerciseScreen
            titleKh={exerciseTitle}
            questions={exerciseQuestions}
            onBack={() => setCurrentRoute('main')}
            onFinish={handleFinishExercise}
          />
        );

      case 'quiz_result':
        return (
          <QuizResultScreen
            score={quizScore}
            total={quizTotal}
            answersHistory={quizAnswersHistory}
            onRetry={() => setCurrentRoute('exercise')}
            onBackToHome={() => {
              setCurrentRoute('main');
              setActiveTab('home');
            }}
          />
        );

      case 'mock_exam':
        return (
          <MockExamScreen
            exam={activeMockExam}
            onBack={() => setCurrentRoute('main')}
            onFinishExam={handleFinishMockExam}
          />
        );

      case 'main':
      default:
        // Teacher vs Student Dashboard for Main Route
        if (currentUser.role === 'teacher' && activeTab === 'profile') {
          return (
            <TeacherDashboardScreen
              currentUser={currentUser}
              announcements={announcements}
              lessons={lessons}
              onCreateAnnouncement={(newAnn) => setAnnouncements([newAnn, ...announcements])}
              onCreateLesson={(newLes) => setLessons([newLes, ...lessons])}
            />
          );
        }

        switch (activeTab) {
          case 'home':
            return (
              <HomeScreen
                currentUser={currentUser}
                announcements={announcements}
                recentlyStudied={lessons.slice(0, 3)}
                onOpenLesson={(les) => {
                  setSelectedLesson(les);
                  setCurrentRoute('lesson_detail');
                }}
                onOpenAnnouncement={handleOpenAnnouncement}
                onLikeAnnouncement={handleLikeAnnouncement}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onOpenSearch={() => setIsSearchOpen(true)}
              />
            );

          case 'subjects':
            return (
              <SubjectsScreen
                scienceSubjects={scienceSubjects}
                socialSubjects={socialSubjects}
                defaultStream={currentUser.stream}
                onSelectSubject={(sub) => {
                  setSelectedSubject(sub);
                  setCurrentRoute('subject_detail');
                }}
              />
            );

          case 'ai_tutor':
            return <AITutorScreen initialSubject={selectedSubject?.nameKh} />;

          case 'study_club':
            return <StudyClubScreen />;

          case 'profile':
            return (
              <ProfileScreen
                currentUser={currentUser}
                onUpdateUser={(updated) => setCurrentUser(updated)}
                onLogout={() => setCurrentRoute('splash')}
              />
            );

          default:
            return null;
        }
    }
  };

  const showHeaderAndBottomNav = currentRoute === 'main';

  return (
    <MobileContainer>
      {/* Header */}
      {showHeaderAndBottomNav && (
        <Header
          currentUser={currentUser}
          user={currentUser}
          unreadNotificationsCount={announcements.length}
          onOpenNotifications={() => setIsNotificationDrawerOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onToggleRole={handleRoleSwitchInHeader}
        />
      )}

      {/* Dynamic Screen Container */}
      <main className="flex-1 flex flex-col min-h-0 overflow-y-auto">
        {renderCurrentScreen()}
      </main>

      {/* Bottom Navigation */}
      {showHeaderAndBottomNav && (
        <BottomNav activeTab={activeTab} onTabChange={(tab) => setActiveTab(tab)} />
      )}

      {/* Notifications Drawer */}
      {isNotificationDrawerOpen && (
        <NotificationDrawer
          announcements={announcements}
          onClose={() => setIsNotificationDrawerOpen(false)}
          onOpenAnnouncement={(ann) => {
            setIsNotificationDrawerOpen(false);
            handleOpenAnnouncement(ann);
          }}
        />
      )}

      {/* Search Modal */}
      {isSearchOpen && (
        <SearchModal
          subjects={[...scienceSubjects, ...socialSubjects]}
          lessons={lessons}
          mockExams={sampleMockExams}
          onClose={() => setIsSearchOpen(false)}
          onSelectLesson={(les) => {
            setSelectedLesson(les);
            setCurrentRoute('lesson_detail');
          }}
          onSelectSubject={(sub) => {
            setSelectedSubject(sub);
            setCurrentRoute('subject_detail');
          }}
          onSelectMockExam={(exam) => {
            setActiveMockExam(exam);
            setCurrentRoute('mock_exam');
          }}
        />
      )}
    </MobileContainer>
  );
}

export default App;
