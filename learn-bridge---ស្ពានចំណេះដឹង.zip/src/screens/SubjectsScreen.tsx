import React, { useState } from 'react';
import { Subject, StreamType } from '../types';
import {
  Calculator,
  Zap,
  FlaskConical,
  Dna,
  BookOpen,
  Landmark,
  Scale,
  Globe,
  MapPin,
  Globe2,
  ChevronRight,
} from 'lucide-react';

interface SubjectsScreenProps {
  scienceSubjects: Subject[];
  socialSubjects: Subject[];
  onSelectSubject: (subject: Subject) => void;
  defaultStream?: StreamType;
}

export const SubjectsScreen: React.FC<SubjectsScreenProps> = ({
  scienceSubjects,
  socialSubjects,
  onSelectSubject,
  defaultStream = 'science',
}) => {
  const [activeStream, setActiveStream] = useState<StreamType>(defaultStream);

  const activeSubjects = activeStream === 'science' ? scienceSubjects : socialSubjects;

  const renderSubjectIcon = (iconName: string) => {
    switch (iconName) {
      case 'Calculator':
        return <Calculator className="w-6 h-6" />;
      case 'Zap':
        return <Zap className="w-6 h-6" />;
      case 'FlaskConical':
        return <FlaskConical className="w-6 h-6" />;
      case 'Dna':
        return <Dna className="w-6 h-6" />;
      case 'BookOpen':
        return <BookOpen className="w-6 h-6" />;
      case 'Landmark':
        return <Landmark className="w-6 h-6" />;
      case 'Scale':
        return <Scale className="w-6 h-6" />;
      case 'MapPin':
        return <MapPin className="w-6 h-6" />;
      case 'Globe2':
        return <Globe2 className="w-6 h-6" />;
      default:
        return <Globe className="w-6 h-6" />;
    }
  };

  return (
    <div className="flex-1 bg-slate-50 p-4 space-y-4 animate-fade-in pb-12">
      {/* Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-800">
          មុខវិជ្ជានិងមេរៀន (Subjects)
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          ជ្រើសរើសមុខវិជ្ជាដើម្បីរៀនមេរៀន និងធ្វើលំហាត់ត្រៀមប្រឡង
        </p>
      </div>

      {/* Segmented Control Buttons */}
      <div className="bg-slate-200/80 p-1 rounded-2xl flex items-center gap-1">
        <button
          onClick={() => setActiveStream('science')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeStream === 'science'
              ? 'bg-white text-blue-700 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>🔬 ថ្នាក់វិទ្យាសាស្ត្រ</span>
        </button>

        <button
          onClick={() => setActiveStream('social')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeStream === 'social'
              ? 'bg-white text-amber-700 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <span>📚 ថ្នាក់វិទ្យាសង្គម</span>
        </button>
      </div>

      {/* Subjects Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {activeSubjects.map((sub) => (
          <button
            key={sub.id}
            onClick={() => onSelectSubject(sub)}
            className="bg-white rounded-3xl p-4 border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all text-left flex items-start gap-3.5 group active:scale-98"
          >
            {/* Subject Color Badge */}
            <div
              className={`w-12 h-12 rounded-2xl ${sub.bgGradient} flex items-center justify-center shadow-md shrink-0`}
            >
              {renderSubjectIcon(sub.icon)}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-slate-800 text-sm group-hover:text-blue-600 transition-colors">
                  {sub.nameKh}
                </h3>
                <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 transition-transform group-hover:translate-x-1" />
              </div>
              <p className="text-[10px] text-slate-400 font-medium">
                {sub.nameEn}
              </p>

              <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                {sub.descriptionKh}
              </p>

              <div className="flex items-center gap-2 mt-2 text-[10px] font-semibold text-slate-500">
                <span className="bg-slate-100 px-2 py-0.5 rounded-md">
                  {sub.chaptersCount} មេរៀន
                </span>
                <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded-md">
                  {sub.exercisesCount}+ លំហាត់
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
