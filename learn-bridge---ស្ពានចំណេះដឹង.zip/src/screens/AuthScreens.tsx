import React, { useState } from 'react';
import { UserRole, StreamType, User } from '../types';
import { initialStudentUser, initialTeacherUser } from '../data/mockData';
import { Phone, Lock, School, User as UserIcon, ArrowLeft, ArrowRight, Eye, EyeOff, KeyRound } from 'lucide-react';

interface AuthScreensProps {
  selectedRole: UserRole;
  onAuthSuccess: (user: User) => void;
  onBackToRole: () => void;
}

type AuthMode = 'login' | 'register' | 'forgot_password';

export const AuthScreens: React.FC<AuthScreensProps> = ({
  selectedRole,
  onAuthSuccess,
  onBackToRole,
}) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);

  // Form State
  const [name, setName] = useState(selectedRole === 'student' ? 'សុខ ជា' : 'លោកគ្រូ សុវណ្ណ គីមហុង');
  const [phoneOrEmail, setPhoneOrEmail] = useState('012 345 678');
  const [password, setPassword] = useState('password123');
  const [school, setSchool] = useState('វិទ្យាល័យ ព្រះស៊ីសុវត្ថិ');
  const [stream, setStream] = useState<StreamType>('science');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const baseUser = selectedRole === 'student' ? initialStudentUser : initialTeacherUser;
    onAuthSuccess({
      ...baseUser,
      name: name || baseUser.name,
      phone: phoneOrEmail || baseUser.phone,
      stream,
      school: school || baseUser.school,
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const baseUser = selectedRole === 'student' ? initialStudentUser : initialTeacherUser;
    onAuthSuccess({
      ...baseUser,
      id: `u_${Date.now()}`,
      name: name || 'សិស្សថ្មី',
      role: selectedRole,
      phone: phoneOrEmail,
      school: school || 'វិទ្យាល័យថ្នាក់ទី១២',
      stream,
    });
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpSent(true);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    alert('លេខកូដ OTP ត្រឹមត្រូវ! លេខសម្ងាត់ថ្មីត្រូវបានរក្សាទុក។');
    setMode('login');
  };

  return (
    <div className="flex-1 flex flex-col p-6 bg-slate-50 min-h-[600px]">
      {/* Top Navigation */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBackToRole}
          className="p-2 rounded-full text-slate-500 hover:text-slate-800 hover:bg-slate-200 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
          {selectedRole === 'student' ? '🎓 គណនីសិស្ស' : '👨‍🏫 គណនីគ្រូបង្រៀន'}
        </span>
      </div>

      {/* Mode Titles */}
      <div className="text-center mb-6">
        <h2 className="text-2xl font-extrabold text-slate-800">
          {mode === 'login' && 'ចូលប្រើប្រាស់ (Login)'}
          {mode === 'register' && 'ចុះឈ្មោះបង្កើតគណនី (Register)'}
          {mode === 'forgot_password' && 'ភ្លេចលេខសម្ងាត់ (Forgot Password)'}
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          {mode === 'login' && 'បញ្ចូលលេខទូរស័ព្ទ និងលេខសម្ងាត់របស់អ្នក'}
          {mode === 'register' && 'បំពេញព័ត៌មានសិក្សាថ្នាក់ទី១២ របស់អ្នក'}
          {mode === 'forgot_password' && 'បញ្ចូលលេខទូរស័ព្ទដើម្បីទទួលបានលេខកូដ OTP'}
        </p>
      </div>

      {/* LOGIN FORM */}
      {mode === 'login' && (
        <form onSubmit={handleLogin} className="space-y-4 max-w-sm mx-auto w-full flex-1">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              លេខទូរស័ព្ទ ឬ អ៊ីមែល
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="text"
                value={phoneOrEmail}
                onChange={(e) => setPhoneOrEmail(e.target.value)}
                placeholder="012 345 678"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              លេខសម្ងាត់ (Password)
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-10 pr-10 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-slate-600">
              <input type="checkbox" defaultChecked className="rounded text-blue-600 focus:ring-blue-500" />
              <span>ចងចាំខ្ញុំ</span>
            </label>
            <button
              type="button"
              onClick={() => setMode('forgot_password')}
              className="text-blue-600 font-bold hover:underline"
            >
              ភ្លេចលេខសម្ងាត់?
            </button>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-transform active:scale-95 mt-4"
          >
            <span>ចូលប្រើប្រាស់</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="text-center pt-4 border-t border-slate-200/80">
            <p className="text-xs text-slate-500">
              មិនទាន់មានគណនីមែនទេ?{' '}
              <button
                type="button"
                onClick={() => setMode('register')}
                className="text-blue-600 font-bold hover:underline"
              >
                ចុះឈ្មោះឥឡូវនេះ
              </button>
            </p>
          </div>
        </form>
      )}

      {/* REGISTER FORM */}
      {mode === 'register' && (
        <form onSubmit={handleRegister} className="space-y-3.5 max-w-sm mx-auto w-full flex-1">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ឈ្មោះពេញ (Full Name)
            </label>
            <div className="relative">
              <UserIcon className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ឧ. សុខ ជា"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Stream Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ថ្នាក់សិក្សា (Grade 12 Stream)
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setStream('science')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  stream === 'science'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                🔬 ថ្នាក់វិទ្យាសាស្ត្រ
              </button>
              <button
                type="button"
                onClick={() => setStream('social')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  stream === 'social'
                    ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                📚 ថ្នាក់វិទ្យាសង្គម
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ឈ្មោះវិទ្យាល័យ (High School)
            </label>
            <div className="relative">
              <School className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="text"
                value={school}
                onChange={(e) => setSchool(e.target.value)}
                placeholder="វិទ្យាល័យ ព្រះស៊ីសុវត្ថិ"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              លេខទូរស័ព្ទ
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="text"
                value={phoneOrEmail}
                onChange={(e) => setPhoneOrEmail(e.target.value)}
                placeholder="012 345 678"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              លេខសម្ងាត់
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-transform active:scale-95 mt-2"
          >
            <span>បង្កើតគណនីថ្មី</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="text-center pt-3 border-t border-slate-200/80">
            <p className="text-xs text-slate-500">
              មានគណនីរួចហើយ?{' '}
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-blue-600 font-bold hover:underline"
              >
                ចូលប្រើប្រាស់
              </button>
            </p>
          </div>
        </form>
      )}

      {/* FORGOT PASSWORD FORM */}
      {mode === 'forgot_password' && (
        <div className="max-w-sm mx-auto w-full flex-1">
          {!otpSent ? (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  លេខទូរស័ព្ទដែលបានចុះឈ្មោះ
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                  <input
                    type="text"
                    value={phoneOrEmail}
                    onChange={(e) => setPhoneOrEmail(e.target.value)}
                    placeholder="012 345 678"
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-transform active:scale-95"
              >
                <span>ផ្ញើលេខកូដ OTP</span>
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-center">
                <p className="text-xs text-blue-800 font-medium">
                  លេខកូដ OTP ៦ ខ្ទង់ត្រូវបានផ្ញើទៅកាន់ <strong>{phoneOrEmail}</strong>
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  បញ្ចូលលេខកូដ OTP (៦ ខ្ទង់)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                  <input
                    type="text"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="123456"
                    required
                    maxLength={6}
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold tracking-widest text-center focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 transition-transform active:scale-95"
              >
                <span>ផ្ទៀងផ្ទាត់ និងផ្លាស់ប្តូរលេខសម្ងាត់</span>
              </button>
            </form>
          )}

          <div className="text-center pt-4 mt-4 border-t border-slate-200/80">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setOtpSent(false);
              }}
              className="text-xs text-slate-500 hover:text-slate-800 font-bold"
            >
              ← ត្រឡប់ទៅការចូលប្រើប្រាស់វិញ
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
