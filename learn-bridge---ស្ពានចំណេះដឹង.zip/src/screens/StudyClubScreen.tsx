import React, { useState } from 'react';
import { StudyClub, ClubPost, SharedFile } from '../types';
import { initialStudyClubs } from '../data/mockData';
import {
  Users,
  Plus,
  Search,
  MessageSquare,
  FileText,
  Calendar,
  Send,
  Download,
  Share2,
  ArrowLeft,
  Sparkles,
  CheckCircle2,
  X,
} from 'lucide-react';

export const StudyClubScreen: React.FC = () => {
  const [clubs, setClubs] = useState<StudyClub[]>(initialStudyClubs);
  const [selectedClub, setSelectedClub] = useState<StudyClub | null>(null);
  const [activeTab, setActiveTab] = useState<'feed' | 'files' | 'sessions'>('feed');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [joinCode, setJoinCode] = useState('');

  // Create Club Form State
  const [newClubName, setNewClubName] = useState('');
  const [newClubCategory, setNewClubCategory] = useState('គណិតវិទ្យា');
  const [newClubDesc, setNewClubDesc] = useState('');

  const filteredClubs = clubs.filter(
    (c) =>
      c.nameKh.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.categoryKh.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateClub = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClubName.trim()) return;

    const newClub: StudyClub = {
      id: `club_${Date.now()}`,
      nameKh: newClubName,
      categoryKh: newClubCategory,
      coverImg: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&auto=format&fit=crop&q=80',
      avatar: '🎓',
      membersCount: 1,
      descriptionKh: newClubDesc || 'ក្លឹបសិក្សាបង្កើតថ្មីសម្រាប់ត្រៀមប្រឡងបាក់ឌុប',
      creatorName: 'សុខ ជា',
      creatorRole: 'student',
      posts: [],
      files: [],
    };

    setClubs([newClub, ...clubs]);
    setShowCreateModal(false);
    setNewClubName('');
    setNewClubDesc('');
    setSelectedClub(newClub);
  };

  const handlePostInClub = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim() || !selectedClub) return;

    const post: ClubPost = {
      id: `cp_${Date.now()}`,
      authorName: 'សុខ ជា',
      authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      authorRole: 'student',
      content: newPostContent,
      timestamp: 'ទើបតែឥឡូវ',
      likes: 0,
      comments: 0,
    };

    const updatedClub = {
      ...selectedClub,
      posts: [post, ...selectedClub.posts],
    };

    setSelectedClub(updatedClub);
    setClubs(clubs.map((c) => (c.id === selectedClub.id ? updatedClub : c)));
    setNewPostContent('');
  };

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in pb-12">
      {!selectedClub ? (
        /* MAIN CLUBS LIST VIEW */
        <div className="p-4 space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-extrabold text-slate-800">
                ក្លឹបសិក្សា (Study Clubs)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                ចូលរួមក្រុមរៀនរួមគ្នាជាមួយមិត្តភក្តិ និងគ្រូបង្រៀន
              </p>
            </div>

            <button
              onClick={() => setShowCreateModal(true)}
              className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-2xl shadow-sm flex items-center gap-1.5 transition-transform active:scale-95 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>បង្កើតក្លឹប</span>
            </button>
          </div>

          {/* Search & Join Bar */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ស្វែងរកក្លឹបសិក្សា..."
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              />
            </div>

            <button
              onClick={() => setShowJoinModal(true)}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-2xl transition-colors"
            >
              បញ្ចូលកូដ
            </button>
          </div>

          {/* Clubs Grid List */}
          <div className="space-y-3">
            {filteredClubs.map((club) => (
              <button
                key={club.id}
                onClick={() => setSelectedClub(club)}
                className="w-full bg-white rounded-3xl p-4 border border-slate-200 shadow-sm hover:border-blue-300 hover:shadow-md transition-all text-left block group active:scale-98"
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center text-xl font-bold shrink-0 border border-blue-100 shadow-2xs">
                    {club.avatar}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-extrabold text-slate-800 text-sm group-hover:text-blue-600 transition-colors truncate">
                        {club.nameKh}
                      </h3>
                      <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full shrink-0">
                        {club.categoryKh}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {club.descriptionKh}
                    </p>

                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-100 text-[10px] text-slate-400">
                      <span className="flex items-center gap-1 text-slate-600 font-semibold">
                        <Users className="w-3.5 h-3.5 text-blue-600" /> {club.membersCount} សមាជិក
                      </span>
                      <span>បង្កើតដោយ {club.creatorName}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* SINGLE CLUB DETAIL VIEW */
        <div className="flex-1 flex flex-col">
          {/* Cover & Header */}
          <div className="relative">
            <img
              src={selectedClub.coverImg}
              alt={selectedClub.nameKh}
              className="w-full h-36 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/40 to-transparent" />

            <button
              onClick={() => setSelectedClub(null)}
              className="absolute top-3 left-3 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="absolute bottom-3 left-4 right-4 text-white">
              <span className="text-[10px] font-bold bg-blue-600 px-2 py-0.5 rounded-full border border-blue-400">
                {selectedClub.categoryKh}
              </span>
              <h1 className="text-base font-extrabold mt-1">{selectedClub.nameKh}</h1>
              <p className="text-[11px] text-slate-200/90">{selectedClub.membersCount} សមាជិកចូលរួម</p>
            </div>
          </div>

          {/* Club Tabs */}
          <div className="bg-white border-b border-slate-200 flex text-xs font-bold">
            <button
              onClick={() => setActiveTab('feed')}
              className={`flex-1 py-3 text-center border-b-2 transition-all ${
                activeTab === 'feed'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500'
              }`}
            >
              💬 ការពិភាក្សា ({(selectedClub.posts || []).length})
            </button>

            <button
              onClick={() => setActiveTab('files')}
              className={`flex-1 py-3 text-center border-b-2 transition-all ${
                activeTab === 'files'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500'
              }`}
            >
              📁 ឯកសារ ({(selectedClub.files || []).length})
            </button>

            <button
              onClick={() => setActiveTab('sessions')}
              className={`flex-1 py-3 text-center border-b-2 transition-all ${
                activeTab === 'sessions'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500'
              }`}
            >
              📅 ការណាត់ជួប
            </button>
          </div>

          {/* Tab Contents */}
          <div className="p-4 space-y-4 flex-1 overflow-y-auto">
            {activeTab === 'feed' && (
              <div className="space-y-3">
                {/* Post Creator Box */}
                <form
                  onSubmit={handlePostInClub}
                  className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs space-y-2"
                >
                  <input
                    type="text"
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder="ចែករំលែកមតិ ឬសួរសំណួរក្នុងក្លឹប..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={!newPostContent.trim()}
                      className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-xs"
                    >
                      បង្ហោះ
                    </button>
                  </div>
                </form>

                {/* Posts List */}
                {(selectedClub.posts || []).map((p) => (
                  <div key={p.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-xs space-y-2">
                    <div className="flex items-center gap-2.5">
                      <img src={p.authorAvatar} alt={p.authorName} className="w-8 h-8 rounded-full object-cover" />
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">{p.authorName}</h4>
                        <span className="text-[9px] text-slate-400">{p.timestamp}</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed">{p.content}</p>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'files' && (
              <div className="space-y-2.5">
                {(selectedClub.files || []).map((f) => (
                  <div key={f.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-xs flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-red-50 text-red-600 rounded-xl">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800 truncate max-w-[180px]">{f.name}</h4>
                        <span className="text-[10px] text-slate-400">{f.size} • ដោយ {f.uploader}</span>
                      </div>
                    </div>
                    <button className="p-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-600">
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'sessions' && (
              <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-xs space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-700">
                  <Calendar className="w-4 h-4" />
                  <span>ការណាត់ជួបសិក្សាបន្ទាប់</span>
                </div>
                {selectedClub.upcomingSession ? (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs space-y-1">
                    <h4 className="font-bold text-blue-900">{selectedClub.upcomingSession.title}</h4>
                    <p className="text-blue-800">📅 {selectedClub.upcomingSession.date} ⏰ {selectedClub.upcomingSession.time}</p>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">មិនទាន់មានការណាត់ជួបសិក្សាឡើយ</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create Club Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form onSubmit={handleCreateClub} className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-800 text-sm">បង្កើតក្លឹបសិក្សាថ្មី</h3>
              <button type="button" onClick={() => setShowCreateModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ឈ្មោះក្លឹបសិក្សា</label>
              <input
                type="text"
                value={newClubName}
                onChange={(e) => setNewClubName(e.target.value)}
                placeholder="ឧ. ក្លឹបគណិតវិទ្យាបាក់ឌុប A"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ប្រភេទមុខវិជ្ជា</label>
              <select
                value={newClubCategory}
                onChange={(e) => setNewClubCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="គណិតវិទ្យា">គណិតវិទ្យា</option>
                <option value="រូបវិទ្យា">រូបវិទ្យា</option>
                <option value="គីមីវិទ្យា">គីមីវិទ្យា</option>
                <option value="ជីវវិទ្យា">ជីវវិទ្យា</option>
                <option value="អក្សរសាស្ត្រខ្មែរ">អក្សរសាស្ត្រខ្មែរ</option>
                <option value="ប្រវត្តិវិទ្យា">ប្រវត្តិវិទ្យា</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ការពណ៌នា</label>
              <textarea
                value={newClubDesc}
                onChange={(e) => setNewClubDesc(e.target.value)}
                placeholder="រៀបរាប់អំពីគោលបំណងក្លឹប..."
                rows={3}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button type="submit" className="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs">
              បង្កើតក្លឹបឥឡូវនេះ
            </button>
          </form>
        </div>
      )}

      {/* Join Club Modal */}
      {showJoinModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-800 text-sm">ចូលរួមជាមួយកូដក្លឹប</h3>
              <button onClick={() => setShowJoinModal(false)}><X className="w-4 h-4 text-slate-400" /></button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">បញ្ចូលកូដក្លឹប (៦ ខ្ទង់)</label>
              <input
                type="text"
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value)}
                placeholder="BACII2026"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-center tracking-widest focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              onClick={() => {
                alert('ចូលរួមបានជោគជ័យ!');
                setShowJoinModal(false);
              }}
              className="w-full py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              ចូលរួមឥឡូវនេះ
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
