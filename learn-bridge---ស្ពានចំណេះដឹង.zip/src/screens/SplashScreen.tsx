import React from 'react';
import { ArrowRight, Sparkles, BookOpenCheck } from 'lucide-react';

interface SplashScreenProps {
  onStart: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-between p-6 bg-gradient-to-b from-blue-700 via-blue-600 to-indigo-900 text-white min-h-[600px] text-center relative overflow-hidden">
      {/* Decorative Light Effects */}
      <div className="absolute top-[-20%] left-[-20%] w-[300px] h-[300px] rounded-full bg-blue-400/20 blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[250px] h-[250px] rounded-full bg-orange-500/20 blur-3xl pointer-events-none" />

      {/* Top Badge */}
      <div className="pt-8">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-blue-100 text-xs font-semibold border border-white/20 shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
          កម្មវិធីរៀនត្រៀមប្រឡងបាក់ឌុប BACII
        </span>
      </div>

      {/* Hero Visual Logo & Title */}
      <div className="my-auto flex flex-col items-center max-w-xs">
        <div className="w-24 h-24 rounded-3xl bg-white/10 backdrop-blur-md p-1 border border-white/20 shadow-2xl flex items-center justify-center mb-6 transform hover:rotate-3 transition-transform">
          <div className="w-full h-full rounded-2xl bg-gradient-to-tr from-blue-500 via-blue-600 to-orange-500 flex items-center justify-center shadow-inner">
            <BookOpenCheck className="w-12 h-12 text-white" />
          </div>
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight text-white mb-2 leading-tight">
          Learn Bridge
        </h1>
        <p className="text-xl font-bold text-amber-300 mb-4 font-khmer">
          ស្ពានចំណេះដឹង
        </p>

        <p className="text-xs text-blue-100/90 leading-relaxed max-w-xs font-khmer">
          វេទិកាសិក្សាអប់រំឌីជីថលសម្រាប់សិស្សថ្នាក់ទី១២ ត្រៀមប្រឡងបាក់ឌុប
          ទទួលបាននិទ្ទេស A ដោយទំនុកចិត្ត និងប្រសិទ្ធភាពខ្ពស់។
        </p>
      </div>

      {/* Bottom Action Button */}
      <div className="w-full max-w-xs pb-6 space-y-3">
        <button
          onClick={onStart}
          className="w-full py-3.5 px-6 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold text-sm rounded-2xl shadow-lg shadow-orange-500/30 flex items-center justify-center gap-2 transition-all active:scale-95"
        >
          <span>ចាប់ផ្តើមសិក្សា</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <p className="text-[10px] text-blue-200/70">
          ក្រសួងអប់រំ យុវជន និងកីឡា • Grade 12 BACII 2026
        </p>
      </div>
    </div>
  );
};
