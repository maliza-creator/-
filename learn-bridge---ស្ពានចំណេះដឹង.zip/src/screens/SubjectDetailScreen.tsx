import React, { useState } from 'react';
import { Subject, Lesson } from '../types';
import { ArrowLeft, Search, CheckCircle2, Clock, ChevronRight, BookOpen, Award } from 'lucide-react';

interface SubjectDetailScreenProps {
  subject: Subject;
  lessons: Lesson[];
  onBack: () => void;
  onSelectLesson: (lesson: Lesson) => void;
}

export const SubjectDetailScreen: React.FC<SubjectDetailScreenProps> = ({
  subject,
  lessons = [],
  onBack,
  onSelectLesson,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const safeLessons = lessons || [];

  const filteredLessons = safeLessons.filter(
    (l) =>
      l.titleKh?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.titleEn?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in pb-12">
      {/* Header Banner */}
      <div className={`p-4 pb-6 ${subject.bgGradient} text-white relative shadow-md`}>
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={onBack}
            className="p-2 rounded-full bg-black/20 hover:bg-black/30 text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="text-xs font-bold px-3 py-1 rounded-full bg-white/20 backdrop-blur-md border border-white/20">
            {subject.stream === 'science' ? '🔬 ថ្នាក់វិទ្យាសាស្ត្រ' : '📚 ថ្នាក់វិទ្យាសង្គម'}
          </span>
        </div>

        <div className="flex items-start gap-3">
          <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md">
            <BookOpen className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black">{subject.nameKh}</h1>
            <p className="text-xs text-white/80 font-medium">{subject.nameEn}</p>
            <p className="text-xs text-white/90 mt-1 line-clamp-2">{subject.descriptionKh}</p>
          </div>
        </div>

        {/* Progress summary banner */}
        <div className="mt-4 bg-black/20 backdrop-blur-md p-3 rounded-2xl flex items-center justify-between text-xs border border-white/10">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-300" />
            <span>ចំណេះដឹងបញ្ចប់ក្នុងមុខវិជ្ជានេះ</span>
          </div>
          <span className="font-extrabold text-amber-300">២៥%</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-3 flex-1">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ស្វែងរកមេរៀន (ឧ. លីមីត, ដេរីវេ, អាំងតេក្រាល)..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
          />
        </div>

        {/* Chapters Header */}
        <div className="flex items-center justify-between pt-1">
          <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            បញ្ជីមេរៀនទាំងអស់ ({filteredLessons.length})
          </h2>
        </div>

        {/* Lesson List */}
        <div className="space-y-2.5">
          {filteredLessons.map((les) => (
            <button
              key={les.id}
              onClick={() => onSelectLesson(les)}
              className="w-full bg-white rounded-2xl p-3.5 border border-slate-100 shadow-xs hover:border-blue-300 hover:shadow-md transition-all text-left flex items-start justify-between group active:scale-98"
            >
              <div className="flex items-start gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                    les.completed
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-blue-50 text-blue-600'
                  }`}
                >
                  {les.completed ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : les.chapterNumber}
                </div>

                <div>
                  <h3 className="font-bold text-slate-800 text-sm group-hover:text-blue-600 transition-colors">
                    {les.chapterNumber}. {les.titleKh}
                  </h3>
                  <p className="text-[10px] text-slate-400 font-medium">
                    {les.titleEn}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                    {les.summaryKh}
                  </p>

                  <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {les.durationMinutes} នាទី
                    </span>
                    •
                    <span className="text-blue-600 font-semibold">
                      មានលំហាត់ & តេស្ត
                    </span>
                  </div>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 transition-transform group-hover:translate-x-1 shrink-0 mt-2" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
