import React, { useState } from 'react';
import { Lesson } from '../types';
import {
  ArrowLeft,
  BookOpen,
  FileEdit,
  Target,
  Sparkles,
  Lightbulb,
  CheckCircle,
  Share2,
  Bookmark,
} from 'lucide-react';

interface LessonDetailScreenProps {
  lesson: Lesson;
  onBack: () => void;
  onStartExercise: (lesson: Lesson) => void;
  onStartQuiz: (lesson: Lesson) => void;
}

export const LessonDetailScreen: React.FC<LessonDetailScreenProps> = ({
  lesson,
  onBack,
  onStartExercise,
  onStartQuiz,
}) => {
  const [activeTab, setActiveTab] = useState<'learn' | 'notes'>('learn');
  const [isBookmarked, setIsBookmarked] = useState(false);

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in pb-20">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200/80 px-4 py-3 sticky top-0 z-20 shadow-2xs">
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="p-2 rounded-full text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <span className="text-xs font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            ជំពូកទី {lesson.chapterNumber}
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsBookmarked(!isBookmarked)}
              className={`p-2 rounded-full transition-colors ${
                isBookmarked ? 'text-amber-500 bg-amber-50' : 'text-slate-400 hover:bg-slate-100'
              }`}
              title="រក្សាទុកមេរៀន"
            >
              <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-amber-500' : ''}`} />
            </button>
            <button className="p-2 rounded-full text-slate-400 hover:bg-slate-100">
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {/* Title */}
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 leading-tight">
            {lesson.chapterNumber}. {lesson.titleKh}
          </h1>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            {lesson.titleEn} • រយៈពេលរៀន {lesson.durationMinutes} នាទី
          </p>
        </div>

        {/* Top Tab Toggle */}
        <div className="flex border-b border-slate-200 text-xs font-bold">
          <button
            onClick={() => setActiveTab('learn')}
            className={`py-2.5 px-4 border-b-2 transition-all ${
              activeTab === 'learn'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            📘 ការពន្យល់មេរៀន & រូបមន្ត
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`py-2.5 px-4 border-b-2 transition-all ${
              activeTab === 'notes'
                ? 'border-blue-600 text-blue-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            💡 កំណត់ចំណាំលោកគ្រូ
          </button>
        </div>

        {activeTab === 'learn' ? (
          <div className="space-y-4">
            {/* Lesson Explanation Box */}
            <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-xs space-y-3">
              <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-blue-600" />
                ខ្លឹមសារមេរៀន
              </h2>
              <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line font-medium">
                {lesson.explanationKh}
              </div>
            </div>

            {/* Formula Box */}
            {(lesson.formulas || []).length > 0 && (
              <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-4 shadow-md space-y-2.5">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <h3 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    រូបមន្តគ្រឹះសំខាន់ៗសម្រាប់ប្រឡងបាក់ឌុប
                  </h3>
                  <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full text-blue-200">
                    BACII Formula
                  </span>
                </div>

                <div className="space-y-2">
                  {(lesson.formulas || []).map((form, idx) => (
                    <div
                      key={idx}
                      className="bg-white/10 p-2.5 rounded-xl border border-white/10 font-mono text-xs text-blue-100"
                    >
                      {form}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Step-by-Step Worked Examples */}
            {(lesson.examplesKh || []).length > 0 && (
              <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-xs space-y-3">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Lightbulb className="w-4 h-4 text-amber-500" />
                  គំរូលំហាត់ដោះស្រាយ និងជំហានអនុវត្ត
                </h3>

                {(lesson.examplesKh || []).map((ex, idx) => (
                  <div key={idx} className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-2">
                    <p className="text-xs font-bold text-slate-800">
                      សំណួរទី {idx + 1}៖ {ex.question}
                    </p>
                    <div className="text-xs text-emerald-800 font-medium bg-emerald-50 p-2.5 rounded-lg border border-emerald-200/70">
                      <strong>ដំណោះស្រាយ៖</strong> {ex.solution}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="bg-amber-50/80 rounded-2xl p-4 border border-amber-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-amber-600" />
              គន្លឹះ និងចំណាំពិសេសពីលោកគ្រូ
            </h3>
            <p className="text-xs text-amber-950 leading-relaxed font-medium">
              {lesson.teacherNotes}
            </p>
          </div>
        )}
      </div>

      {/* Bottom Sticky Action Buttons */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 z-30 shadow-lg">
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setActiveTab('learn')}
            className={`py-2.5 px-2 rounded-xl text-[11px] font-bold flex flex-col items-center justify-center gap-1 transition-all ${
              activeTab === 'learn'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>📘 រៀនមេរៀន</span>
          </button>

          <button
            onClick={() => onStartExercise(lesson)}
            className="py-2.5 px-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-[11px] font-bold flex flex-col items-center justify-center gap-1 shadow-sm transition-transform active:scale-95"
          >
            <FileEdit className="w-4 h-4" />
            <span>📝 លំហាត់អនុវត្ត</span>
          </button>

          <button
            onClick={() => onStartQuiz(lesson)}
            className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex flex-col items-center justify-center gap-1 shadow-sm transition-transform active:scale-95"
          >
            <Target className="w-4 h-4" />
            <span>🎯 ធ្វើតេស្ត</span>
          </button>
        </div>
      </div>
    </div>
  );
};
