import React, { useState, useEffect } from 'react';
import { ExerciseQuestion } from '../types';
import {
  ArrowLeft,
  Clock,
  Bookmark,
  Lightbulb,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface ExerciseScreenProps {
  titleKh: string;
  questions: ExerciseQuestion[];
  onBack: () => void;
  onFinish: (score: number, total: number, answersHistory: any[]) => void;
}

export const ExerciseScreen: React.FC<ExerciseScreenProps> = ({
  titleKh,
  questions = [],
  onBack,
  onFinish,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [userAnswers, setUserAnswers] = useState<any[]>([]);
  const [secondsElapsed, setSecondsElapsed] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const safeQuestions = questions || [];
  const currentQ = safeQuestions[currentIndex] || safeQuestions[0] || {
    id: 'default',
    questionKh: 'គ្មានសំណួរ',
    options: [],
    correctIndex: 0,
    hintKh: '',
    explanationKh: '',
  };

  const handleSelectOption = (index: number) => {
    if (isAnswerChecked) return;
    setSelectedOption(index);
  };

  const handleCheckAnswer = () => {
    if (selectedOption === null) return;
    setIsAnswerChecked(true);
  };

  const handleNextQuestion = () => {
    const isCorrect = selectedOption === currentQ.correctIndex;
    const record = {
      questionId: currentQ.id,
      questionKh: currentQ.questionKh,
      selectedOption,
      correctIndex: currentQ.correctIndex,
      isCorrect,
    };

    const newAnswers = [...userAnswers, record];
    setUserAnswers(newAnswers);

    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      setShowHint(false);
      setIsBookmarked(false);
    } else {
      // Calculate score
      const correctCount = newAnswers.filter((a) => a.isCorrect).length;
      onFinish(correctCount, questions.length, newAnswers);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in pb-16">
      {/* Top Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-3 sticky top-0 z-20 shadow-2xs">
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full text-slate-600 hover:bg-slate-100"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <h2 className="text-xs font-bold text-slate-800 truncate max-w-[180px]">
            {titleKh}
          </h2>

          <div className="flex items-center gap-1.5 font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-full">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span>{formatTime(secondsElapsed)}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div
            className="bg-blue-600 h-full rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / (safeQuestions.length || 1)) * 100}%` }}
          />
        </div>
      </div>

      {/* Main Question Body */}
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        {/* Question Card */}
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-sm space-y-4 relative">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <span className="text-xs font-extrabold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              សំណួរ {currentIndex + 1} / {safeQuestions.length}
            </span>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowHint(!showHint)}
                className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                  showHint
                    ? 'bg-amber-100 text-amber-800 border-amber-300'
                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                <span>តម្រុយ (Hint)</span>
              </button>

              <button
                onClick={() => setIsBookmarked(!isBookmarked)}
                className={`p-1.5 rounded-full transition-colors ${
                  isBookmarked ? 'text-amber-500 bg-amber-50' : 'text-slate-400'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-500' : ''}`} />
              </button>
            </div>
          </div>

          <h3 className="text-sm font-extrabold text-slate-900 leading-snug">
            {currentQ.questionKh}
          </h3>

          {/* Hint Dropdown Drawer */}
          {showHint && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900 font-medium flex items-start gap-2 animate-fade-in">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <strong>តម្រុយ៖</strong> {currentQ.hintKh}
              </div>
            </div>
          )}

          {/* Options */}
          <div className="space-y-2.5 pt-2">
            {(currentQ.options || []).map((opt, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrectOption = idx === currentQ.correctIndex;

              let optionStyle =
                'bg-slate-50 border-slate-200 text-slate-800 hover:border-blue-300';

              if (isSelected) {
                optionStyle = 'bg-blue-50 border-blue-600 text-blue-900 font-bold';
              }

              if (isAnswerChecked) {
                if (isCorrectOption) {
                  optionStyle =
                    'bg-emerald-50 border-emerald-500 text-emerald-900 font-bold';
                } else if (isSelected && !isCorrectOption) {
                  optionStyle = 'bg-red-50 border-red-500 text-red-900 font-bold';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-3.5 rounded-2xl border-2 text-xs text-left font-medium transition-all flex items-center justify-between ${optionStyle}`}
                >
                  <span>{opt}</span>

                  {isAnswerChecked && isCorrectOption && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  )}

                  {isAnswerChecked && isSelected && !isCorrectOption && (
                    <XCircle className="w-5 h-5 text-red-500 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Answer Explanation Modal */}
          {isAnswerChecked && (
            <div className="p-3.5 bg-blue-50/80 border border-blue-200 rounded-2xl text-xs text-blue-950 font-medium space-y-1 animate-fade-in">
              <strong className="text-blue-900 block font-bold">
                💡 ការបកស្រាយចម្លើយ៖
              </strong>
              <p className="leading-relaxed">{currentQ.explanationKh}</p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Floating Navigation Buttons */}
      <div className="p-4 bg-white border-t border-slate-200 sticky bottom-0 z-20 shadow-lg">
        {!isAnswerChecked ? (
          <button
            onClick={handleCheckAnswer}
            disabled={selectedOption === null}
            className={`w-full py-3 rounded-2xl text-xs font-bold transition-all shadow-md ${
              selectedOption !== null
                ? 'bg-blue-600 hover:bg-blue-700 text-white active:scale-98'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            ផ្ទៀងផ្ទាត់ចម្លើយ
          </button>
        ) : (
          <button
            onClick={handleNextQuestion}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-2xl shadow-md flex items-center justify-center gap-2 active:scale-98 transition-all"
          >
            <span>{currentIndex < questions.length - 1 ? 'សំណួរដកបន្ទាប់' : 'បញ្ចប់លំហាត់'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
