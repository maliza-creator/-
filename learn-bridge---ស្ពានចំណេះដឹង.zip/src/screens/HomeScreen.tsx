import React from 'react';
import { User, Announcement, Lesson } from '../types';
import { AnnouncementCard } from '../components/AnnouncementCard';
import {
  Flame,
  BookOpen,
  Sparkles,
  Search,
  Bot,
  Award,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';

interface HomeScreenProps {
  currentUser: User;
  announcements: Announcement[];
  recentlyStudied: Lesson[];
  onOpenLesson: (lesson: Lesson) => void;
  onOpenAnnouncement: (announcement: Announcement) => void;
  onLikeAnnouncement: (id: string) => void;
  onNavigateTab: (tab: 'subjects' | 'ai_tutor' | 'study_club' | 'profile') => void;
  onOpenSearch: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  currentUser,
  announcements = [],
  recentlyStudied = [],
  onOpenLesson,
  onOpenAnnouncement,
  onLikeAnnouncement,
  onNavigateTab,
  onOpenSearch,
}) => {
  const safeUser = currentUser || {
    name: 'សិស្ស',
    stream: 'science',
    streakDays: 1,
  };
  const safeRecentlyStudied = recentlyStudied || [];
  const safeAnnouncements = announcements || [];
  return (
    <div className="flex-1 bg-slate-50 pb-8 space-y-5 animate-fade-in">
      {/* Search Bar Banner */}
      <div className="px-4 pt-3">
        <button
          onClick={onOpenSearch}
          className="w-full bg-white border border-slate-200/90 rounded-2xl px-3.5 py-2.5 text-slate-400 text-xs flex items-center justify-between shadow-xs hover:border-blue-300 transition-all active:scale-98"
        >
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-blue-500" />
            <span>ស្វែងរកមេរៀន វិញ្ញាសា ឬលំហាត់បាក់ឌុប...</span>
          </div>
          <span className="text-[10px] font-bold bg-blue-50 text-blue-600 px-2 py-0.5 rounded-md">
            BACII
          </span>
        </button>
      </div>

      {/* Hero Streak & Progress Welcome Banner */}
      <div className="px-4">
        <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-3xl p-5 shadow-xl shadow-blue-200/60 relative overflow-hidden">
          {/* Decorative Background Accents */}
          <div className="absolute right-[-20px] bottom-[-20px] w-48 h-48 rounded-full bg-white/10 blur-2xl pointer-events-none" />

          <div className="flex items-start justify-between mb-4 relative z-10">
            <div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-[11px] font-bold text-blue-100 border border-white/25 mb-2 backdrop-blur-md">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                {safeUser.stream === 'science' ? '🔬 ថ្នាក់វិទ្យាសាស្ត្រ' : '📚 ថ្នាក់វិទ្យាសង្គម'}
              </span>
              <h2 className="text-lg font-extrabold leading-tight">
                សួស្ដី, {safeUser.name}! 👋
              </h2>
              <p className="text-xs text-blue-100/90 mt-1">
                អ្នកបានបញ្ចប់ ៧៥% នៃគោលដៅប្រចាំសប្តាហ៍។ រួចរាល់សម្រាប់ការសិក្សាថ្ងៃនេះ?
              </p>
            </div>

            {/* Streak Counter Badge */}
            <div className="bg-orange-50/95 text-orange-600 font-extrabold px-3 py-1.5 rounded-full border border-orange-200 shadow-sm text-center flex items-center gap-1.5 shrink-0 backdrop-blur-md">
              <Flame className="w-4 h-4 text-orange-500 fill-orange-500 animate-bounce" />
              <span className="text-xs">{safeUser.streakDays} ថ្ងៃជាប់គ្នា</span>
            </div>
          </div>

          {/* Today's Progress Bar */}
          <div className="bg-white/20 backdrop-blur-md p-3.5 rounded-2xl border border-white/20 relative z-10">
            <div className="flex items-center justify-between text-xs mb-2 font-bold">
              <span className="flex items-center gap-1.5 text-white text-[11px]">
                <TrendingUp className="w-4 h-4 text-emerald-300" />
                វឌ្ឍនភាពថ្ងៃនេះ
              </span>
              <span className="text-amber-300 font-extrabold text-[11px]">៧៥%</span>
            </div>
            <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
              <div
                className="bg-white h-full rounded-full transition-all duration-500"
                style={{ width: '75%' }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Category Shortcuts */}
      <div className="px-4">
        <div className="grid grid-cols-4 gap-2">
          <button
            onClick={() => onNavigateTab('subjects')}
            className="flex flex-col items-center justify-center p-2.5 bg-white rounded-2xl border border-slate-100 shadow-xs hover:border-blue-200 transition-all active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-1">
              <BookOpen className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-slate-700">មុខវិជ្ជា</span>
          </button>

          <button
            onClick={() => onNavigateTab('ai_tutor')}
            className="flex flex-col items-center justify-center p-2.5 bg-white rounded-2xl border border-slate-100 shadow-xs hover:border-orange-200 transition-all active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center mb-1">
              <Bot className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-slate-700">AI Tutor</span>
          </button>

          <button
            onClick={() => onNavigateTab('study_club')}
            className="flex flex-col items-center justify-center p-2.5 bg-white rounded-2xl border border-slate-100 shadow-xs hover:border-emerald-200 transition-all active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-1">
              <Award className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-slate-700">ក្លឹបសិក្សា</span>
          </button>

          <button
            onClick={() => onNavigateTab('profile')}
            className="flex flex-col items-center justify-center p-2.5 bg-white rounded-2xl border border-slate-100 shadow-xs hover:border-indigo-200 transition-all active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-1">
              <TrendingUp className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-slate-700">លទ្ធផល</span>
          </button>
        </div>
      </div>

      {/* Continue Learning Card */}
      {safeRecentlyStudied.length > 0 && (
        <div className="px-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-1.5 h-3.5 bg-blue-600 rounded-full" />
              បន្តការសិក្សា (Continue Learning)
            </h3>
            <button
              onClick={() => onNavigateTab('subjects')}
              className="text-[11px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
            >
              មើលទាំងអស់ <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
                  ជំពូកទី ២ • គណិតវិទ្យា
                </span>
                <h4 className="font-bold text-slate-800 text-sm mt-2">
                  {safeRecentlyStudied[0].titleKh} ({safeRecentlyStudied[0].titleEn})
                </h4>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                  {safeRecentlyStudied[0].summaryKh}
                </p>
              </div>

              <button
                onClick={() => onOpenLesson(safeRecentlyStudied[0])}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-95 shrink-0 ml-3"
              >
                ចូលរៀន
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Recently Studied Lessons (Horizontal Scroll) */}
      <div className="px-4">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <span className="w-1.5 h-3.5 bg-orange-500 rounded-full" />
          មេរៀនបានរៀនថ្មីៗ (Recently Studied)
        </h3>

        <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
          {safeRecentlyStudied.map((les) => (
            <button
              key={les.id}
              onClick={() => onOpenLesson(les)}
              className="min-w-[180px] bg-white rounded-3xl p-4 border border-slate-200 shadow-sm hover:border-blue-300 hover:shadow-md text-left transition-all shrink-0 active:scale-98"
            >
              <div className="w-9 h-9 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center text-xs font-extrabold mb-2 border border-blue-100">
                {les.chapterNumber}
              </div>
              <h4 className="text-xs font-bold text-slate-800 truncate">
                {les.titleKh}
              </h4>
              <p className="text-[10px] text-slate-400 font-medium mt-0.5">{les.durationMinutes} នាទី</p>
            </button>
          ))}
        </div>
      </div>

      {/* Facebook-style Educational Announcement Feed */}
      <div className="px-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <span className="w-1.5 h-3.5 bg-emerald-500 rounded-full" />
            ព័ត៌មាន និងការប្រកាសពីគ្រូបង្រៀន (Announcements)
          </h3>
        </div>

        <div className="space-y-3">
          {safeAnnouncements.map((ann) => (
            <AnnouncementCard
              key={ann.id}
              announcement={ann}
              onLike={onLikeAnnouncement}
              onOpenTarget={onOpenAnnouncement}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
