import React, { useState } from 'react';
import { User, Lesson, Announcement } from '../types';
import {
  Upload,
  Plus,
  BookOpen,
  FileEdit,
  Megaphone,
  Users,
  BarChart2,
  Trash2,
  Edit,
  CheckCircle2,
  X,
  FileText,
} from 'lucide-react';

interface TeacherDashboardScreenProps {
  currentUser: User;
  announcements: Announcement[];
  lessons: Lesson[];
  onCreateAnnouncement: (announcement: Announcement) => void;
  onCreateLesson: (lesson: Lesson) => void;
}

export const TeacherDashboardScreen: React.FC<TeacherDashboardScreenProps> = ({
  currentUser,
  announcements = [],
  lessons = [],
  onCreateAnnouncement,
  onCreateLesson,
}) => {
  const safeAnnouncements = announcements || [];
  const safeLessons = lessons || [];
  const [activeSubTab, setActiveSubTab] = useState<'content' | 'students' | 'announcements'>('content');
  const [showUploadLessonModal, setShowUploadLessonModal] = useState(false);
  const [showCreateAnnouncementModal, setShowCreateAnnouncementModal] = useState(false);

  // Lesson Form State
  const [lessonTitleKh, setLessonTitleKh] = useState('');
  const [lessonSubject, setLessonSubject] = useState('គណិតវិទ្យា');
  const [lessonChapter, setLessonChapter] = useState(1);
  const [lessonExplanation, setLessonExplanation] = useState('');

  // Announcement Form State
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annType, setAnnType] = useState<'mock_exam' | 'new_lesson' | 'quiz' | 'exercise'>('new_lesson');

  const handleUploadLessonSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lessonTitleKh.trim()) return;

    const newLesson: Lesson = {
      id: `les_${Date.now()}`,
      subjectId: 'sub_math',
      chapterNumber: Number(lessonChapter),
      titleKh: lessonTitleKh,
      titleEn: 'Teacher Uploaded Lesson',
      summaryKh: lessonExplanation.substring(0, 60) + '...',
      explanationKh: lessonExplanation,
      formulas: ['f(x) = ax + b', 'lim(x->0) sin x / x = 1'],
      examplesKh: [
        {
          question: 'គណនាលីមីតខាងក្រោម...',
          solution: 'អនុវត្តរូបមន្តគ្រឹះ...',
        },
      ],
      durationMinutes: 20,
      completed: false,
      teacherNotes: 'មេរៀនបង្ហោះដោយលោកគ្រូ ' + currentUser.name,
    };

    onCreateLesson(newLesson);
    setShowUploadLessonModal(false);
    setLessonTitleKh('');
    setLessonExplanation('');
    alert('បង្ហោះមេរៀនថ្មីបានជោគជ័យ!');
  };

  const handleCreateAnnouncementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim()) return;

    const newAnn: Announcement = {
      id: `ann_${Date.now()}`,
      teacherName: currentUser.name,
      teacherAvatar: currentUser.avatar,
      titleKh: annTitle,
      contentKh: annContent,
      type: annType,
      subjectNameKh: 'គណិតវិទ្យា',
      timestamp: 'ទើបតែឥឡូវ',
      likes: 0,
      commentsCount: 0,
      isLiked: false,
    };

    onCreateAnnouncement(newAnn);
    setShowCreateAnnouncementModal(false);
    setAnnTitle('');
    setAnnContent('');
    alert('ប្រកាសព័ត៌មានថ្មីត្រូវបានបង្ហោះ!');
  };

  return (
    <div className="flex-1 bg-slate-50 p-4 space-y-4 animate-fade-in pb-16">
      {/* Teacher Welcome Banner */}
      <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-blue-700 text-white rounded-3xl p-5 shadow-md">
        <div className="flex items-center gap-3">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-12 h-12 rounded-2xl object-cover ring-2 ring-white/30"
          />
          <div>
            <span className="text-[10px] font-bold bg-white/20 px-2 py-0.5 rounded-full border border-white/20">
              👨‍🏫 ផ្ទាំងគ្រប់គ្រងគ្រូបង្រៀន
            </span>
            <h1 className="text-base font-extrabold mt-0.5">{currentUser.name}</h1>
            <p className="text-[11px] text-amber-100">{currentUser.school}</p>
          </div>
        </div>

        {/* Action Controls Grid */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-white/20">
          <button
            onClick={() => setShowUploadLessonModal(true)}
            className="py-2.5 px-3 bg-white text-slate-900 font-bold text-xs rounded-2xl shadow-sm flex items-center justify-center gap-1.5 transition-transform active:scale-95"
          >
            <Upload className="w-4 h-4 text-orange-600" />
            <span>បង្ហោះមេរៀនថ្មី</span>
          </button>

          <button
            onClick={() => setShowCreateAnnouncementModal(true)}
            className="py-2.5 px-3 bg-slate-900/40 hover:bg-slate-900/60 text-white font-bold text-xs rounded-2xl border border-white/20 flex items-center justify-center gap-1.5 transition-transform active:scale-95"
          >
            <Megaphone className="w-4 h-4 text-amber-300" />
            <span>បង្កើតការប្រកាស</span>
          </button>
        </div>
      </div>

      {/* Teacher Stats Cards */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-white p-3.5 rounded-3xl border border-slate-200 shadow-sm text-center">
          <BookOpen className="w-5 h-5 text-blue-600 mx-auto mb-1" />
          <span className="text-[9px] text-slate-400 font-bold block">មេរៀនបានបង្ហោះ</span>
          <span className="text-sm font-extrabold text-slate-800">{safeLessons.length}</span>
        </div>

        <div className="bg-white p-3.5 rounded-3xl border border-slate-200 shadow-sm text-center">
          <Users className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
          <span className="text-[9px] text-slate-400 font-bold block">សិស្សកំពុងរៀន</span>
          <span className="text-sm font-extrabold text-slate-800">១,២៤០</span>
        </div>

        <div className="bg-white p-3.5 rounded-3xl border border-slate-200 shadow-sm text-center">
          <BarChart2 className="w-5 h-5 text-orange-600 mx-auto mb-1" />
          <span className="text-[9px] text-slate-400 font-bold block">ការប្រកាសសរុប</span>
          <span className="text-sm font-extrabold text-slate-800">{safeAnnouncements.length}</span>
        </div>
      </div>

      {/* Management Navigation Tabs */}
      <div className="bg-white border-b border-slate-200 flex text-xs font-bold rounded-2xl p-1 shadow-xs">
        <button
          onClick={() => setActiveSubTab('content')}
          className={`flex-1 py-2 rounded-xl transition-all ${
            activeSubTab === 'content' ? 'bg-orange-500 text-white shadow-xs' : 'text-slate-600'
          }`}
        >
          📘 បញ្ជីមេរៀន
        </button>

        <button
          onClick={() => setActiveSubTab('announcements')}
          className={`flex-1 py-2 rounded-xl transition-all ${
            activeSubTab === 'announcements' ? 'bg-orange-500 text-white shadow-xs' : 'text-slate-600'
          }`}
        >
          📢 ការប្រកាស
        </button>

        <button
          onClick={() => setActiveSubTab('students')}
          className={`flex-1 py-2 rounded-xl transition-all ${
            activeSubTab === 'students' ? 'bg-orange-500 text-white shadow-xs' : 'text-slate-600'
          }`}
        >
          🎓 សិស្សានុសិស្ស
        </button>
      </div>

      {/* Subtab Contents */}
      <div className="space-y-3">
        {activeSubTab === 'content' && (
          <div className="space-y-2">
            {safeLessons.map((les) => (
              <div
                key={les.id}
                className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-xs flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-bold text-slate-800">
                    ជំពូកទី {les.chapterNumber} • {les.titleKh}
                  </h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">{les.summaryKh}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button className="p-1.5 text-slate-400 hover:text-blue-600">
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-1.5 text-slate-400 hover:text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeSubTab === 'announcements' && (
          <div className="space-y-2">
            {safeAnnouncements.map((ann) => (
              <div
                key={ann.id}
                className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800">{ann.titleKh}</h4>
                  <span className="text-[9px] bg-orange-50 text-orange-700 px-2 py-0.5 rounded-full font-bold">
                    {ann.timestamp}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">{ann.contentKh}</p>
              </div>
            ))}
          </div>
        )}

        {activeSubTab === 'students' && (
          <div className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              បញ្ជីឈ្មោះសិស្សបានចុះឈ្មោះសិក្សា (Student Roster)
            </h3>

            <div className="space-y-2">
              {[
                { name: 'សុខ ជា', school: 'វិទ្យាល័យ ព្រះស៊ីសុវត្ថិ', grade: 'និទ្ទេស A (៩២%)' },
                { name: 'កែវ សេរី', school: 'វិទ្យាល័យ បាក់ទូក', grade: 'និទ្ទេស B (៨៤%)' },
                { name: 'ឡុង វិបុល', school: 'វិទ្យាល័យ ឥន្ទ្រទេវី', grade: 'និទ្ទេស A (៩៥%)' },
              ].map((st, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-center justify-between text-xs"
                >
                  <div>
                    <h4 className="font-bold text-slate-800">{st.name}</h4>
                    <p className="text-[10px] text-slate-400">{st.school}</p>
                  </div>
                  <span className="font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    {st.grade}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Upload Lesson Modal */}
      {showUploadLessonModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleUploadLessonSubmit}
            className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-3"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-800 text-sm">បង្ហោះមេរៀនថ្មី</h3>
              <button type="button" onClick={() => setShowUploadLessonModal(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">មុខវិជ្ជា</label>
              <select
                value={lessonSubject}
                onChange={(e) => setLessonSubject(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="គណិតវិទ្យា">គណិតវិទ្យា</option>
                <option value="រូបវិទ្យា">រូបវិទ្យា</option>
                <option value="គីមីវិទ្យា">គីមីវិទ្យា</option>
                <option value="ជីវវិទ្យា">ជីវវិទ្យា</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ជំពូកទី</label>
              <input
                type="number"
                value={lessonChapter}
                onChange={(e) => setLessonChapter(Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ចំណងជើងមេរៀន</label>
              <input
                type="text"
                value={lessonTitleKh}
                onChange={(e) => setLessonTitleKh(e.target.value)}
                placeholder="ឧ. អាំងតេក្រាលមិនកំណត់"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ខ្លឹមសារ និងការពន្យល់មេរៀន</label>
              <textarea
                value={lessonExplanation}
                onChange={(e) => setLessonExplanation(e.target.value)}
                placeholder="បញ្ចូលអត្ថបទពន្យល់មេរៀន និងរូបមន្ត..."
                rows={3}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-orange-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              រក្សាទុក និងបង្ហោះ
            </button>
          </form>
        </div>
      )}

      {/* Create Announcement Modal */}
      {showCreateAnnouncementModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateAnnouncementSubmit}
            className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-3"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-800 text-sm">បង្កើតការប្រកាសថ្មី</h3>
              <button type="button" onClick={() => setShowCreateAnnouncementModal(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ចំណងជើង</label>
              <input
                type="text"
                value={annTitle}
                onChange={(e) => setAnnTitle(e.target.value)}
                placeholder="ឧ. វិញ្ញាសាសាកល្បងបាក់ឌុបថ្មី"
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ប្រភេទ</label>
              <select
                value={annType}
                onChange={(e) => setAnnType(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="mock_exam">📢 វិញ្ញាសាសាកល្បង</option>
                <option value="new_lesson">📘 មេរៀនថ្មី</option>
                <option value="quiz">📝 តេស្តប្រឡង</option>
                <option value="exercise">🔥 លំហាត់អនុវត្ត</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ខ្លឹមសារប្រកាស</label>
              <textarea
                value={annContent}
                onChange={(e) => setAnnContent(e.target.value)}
                placeholder="បញ្ចូលព័ត៌មានលម្អិត..."
                rows={3}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              បង្ហោះការប្រកាស
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
