import React, { useState, useRef, useEffect } from 'react';
import { AIChatMessage } from '../types';
import {
  Send,
  Bot,
  Sparkles,
  Camera,
  Mic,
  Image as ImageIcon,
  Trash2,
  X,
} from 'lucide-react';

interface AITutorScreenProps {
  initialSubject?: string;
}

export const AITutorScreen: React.FC<AITutorScreenProps> = ({ initialSubject }) => {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'm_welcome',
      sender: 'bot',
      text: `សួស្ដី! ខ្ញុំជា **BridgeBot AI** គ្រូបង្រៀនជំនួយការប្រឡងបាក់ឌុបថ្នាក់ទី១២ (BACII AI Tutor)! 🤖✨\n\nតើខ្ញុំអាចជួយដោះស្រាយលំហាត់ ឬពន្យល់មេរៀនអ្វីខ្លះដល់អ្នកនៅថ្ងៃនេះ?`,
      timestamp: 'ទើបតែឥឡូវ',
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    'ពន្យល់មេរៀនលីមីតនៃអនុគមន៍',
    'ដោះស្រាយលំហាត់អាំងតេក្រាលនេះ',
    'បង្កើតសំណួរអនុវត្តបន្ថែម',
    'សង្ខេបជំពូកអក្សរសាស្ត្រខ្មែរ',
    'បកប្រែពាក្យបច្ចេកទេសអង់គ្លេស',
    'ផ្តល់គន្លឹះប្រឡងបាក់ឌុបទទួលបាននិទ្ទេស A',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputPrompt;
    if (!textToSend.trim() && !selectedImage) return;

    const userMsg: AIChatMessage = {
      id: `m_${Date.now()}`,
      sender: 'user',
      text: textToSend,
      imageUri: selectedImage || undefined,
      timestamp: new Date().toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    const imagePayload = selectedImage;
    setSelectedImage(null);
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: textToSend,
          subject: initialSubject || 'Grade 12 BACII Khmer Education',
          imageBase64: imagePayload || undefined,
        }),
      });

      const data = await response.json();

      const botMsg: AIChatMessage = {
        id: `m_bot_${Date.now()}`,
        sender: 'bot',
        text: data.reply || 'សុំទោស មិនមានចម្លើយឆ្លើយតប។',
        timestamp: new Date().toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const errorMsg: AIChatMessage = {
        id: `m_err_${Date.now()}`,
        sender: 'bot',
        text: 'សុំទោស មានបញ្ហាក្នុងការភ្ជាប់ទៅកាន់ AI Tutor។ សូមព្យាយាមម្តងទៀត!',
        timestamp: new Date().toLocaleTimeString('km-KH', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSampleImageUpload = () => {
    // Generate sample BACII math problem image preview base64
    const sampleBase64 =
      'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="150" viewBox="0 0 300 150"><rect width="300" height="150" fill="%231e293b"/><text x="20" y="40" fill="%2338bdf8" font-family="sans-serif" font-size="16" font-weight="bold">BACII 2026 Math Exercise:</text><text x="20" y="80" fill="%23ffffff" font-family="sans-serif" font-size="18">lim (x→0) [ (1 - cos 2x) / x² ] = ?</text><text x="20" y="120" fill="%23f59e0b" font-family="sans-serif" font-size="14">សូមដោះស្រាយ និងពន្យល់ជំហាន</text></svg>';
    setSelectedImage(sampleBase64);
  };

  const handleVoiceInput = () => {
    setIsRecording(true);
    setTimeout(() => {
      setIsRecording(false);
      setInputPrompt('តើរូបមន្តដេរីវេនៃអនុគមន៍អេកស្ប៉ូណង់ស្យែលមានអ្វីខ្លះ?');
    }, 2000);
  };

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in pb-2 overflow-hidden">
      {/* Top AI Header */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white p-4 shadow-lg shadow-blue-200/50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-xs">
            <Bot className="w-6 h-6 text-amber-300 animate-pulse-subtle" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-extrabold text-sm">BridgeBot AI Tutor</h2>
              <span className="text-[9px] font-bold bg-amber-400 text-slate-900 px-2 py-0.5 rounded-full">
                Gemini 3.6
              </span>
            </div>
            <p className="text-[10px] text-blue-100/90 mt-0.5">
              គ្រូបង្រៀន AI ជំនួយការប្រឡងបាក់ឌុប ២៤/៧
            </p>
          </div>
        </div>

        <button
          onClick={() => setMessages([])}
          className="p-2 rounded-xl text-blue-100 hover:bg-white/15 transition-colors"
          title="លុបប្រវត្តិសន្ទនា"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Suggested Prompt Pills */}
      <div className="bg-white border-b border-slate-200/90 p-2.5 overflow-x-auto scrollbar-none flex items-center gap-2 shrink-0">
        <Sparkles className="w-4 h-4 text-amber-500 shrink-0 ml-1" />
        {suggestedPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(p)}
            className="text-[11px] font-semibold text-blue-700 bg-slate-50 hover:bg-blue-50 border border-blue-100 hover:border-blue-300 px-3 py-1.5 rounded-xl whitespace-nowrap transition-all shrink-0 active:scale-95 shadow-2xs"
          >
            "{p}"
          </button>
        ))}
      </div>

      {/* Messages List */}
      <div className="flex-1 p-4 space-y-3.5 overflow-y-auto">
        {messages.map((msg) => {
          const isBot = msg.sender === 'bot';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              {isBot && (
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[82%] rounded-2xl p-3.5 text-xs font-medium leading-relaxed shadow-xs ${
                  isBot
                    ? 'bg-white text-slate-800 border border-slate-100'
                    : 'bg-blue-600 text-white'
                }`}
              >
                {/* Image Preview if user attached image */}
                {msg.imageUri && (
                  <img
                    src={msg.imageUri}
                    alt="Uploaded question"
                    className="w-full h-auto rounded-xl mb-2 border border-slate-200"
                  />
                )}

                <div className="whitespace-pre-line leading-relaxed">
                  {msg.text}
                </div>

                <span
                  className={`text-[9px] mt-1.5 block ${
                    isBot ? 'text-slate-400' : 'text-blue-200'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>
            </div>
          );
        })}

        {/* Loading Spinner */}
        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-slate-500 italic bg-white p-3 rounded-2xl max-w-[200px] border border-slate-100 shadow-xs">
            <Bot className="w-4 h-4 text-blue-600 animate-spin" />
            <span>BridgeBot កំពុងគិត និងដោះស្រាយ...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Selected Image Preview Floating Banner */}
      {selectedImage && (
        <div className="px-4 pb-2">
          <div className="bg-slate-800 text-white p-2 rounded-2xl flex items-center justify-between text-xs border border-slate-700">
            <div className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-amber-400" />
              <span>រូបភាពសំណួរបានជ្រើសរើស</span>
            </div>
            <button
              onClick={() => setSelectedImage(null)}
              className="p-1 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Input Bar */}
      <div className="px-3 py-2 bg-white border-t border-slate-200/90 sticky bottom-0 z-20">
        <div className="flex items-center gap-1.5">
          {/* Photo Scanner Button */}
          <button
            onClick={handleSampleImageUpload}
            className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
            title="ថត/បង្ហោះរូបភាពលំហាត់"
          >
            <Camera className="w-5 h-5 text-blue-600" />
          </button>

          {/* Voice Input Button */}
          <button
            onClick={handleVoiceInput}
            className={`p-2.5 rounded-xl transition-colors ${
              isRecording
                ? 'bg-red-500 text-white animate-pulse'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
            title="និយាយសំណួរ"
          >
            <Mic className="w-5 h-5 text-orange-500" />
          </button>

          {/* Text Input */}
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={isRecording ? 'កំពុងស្តាប់...' : 'សួរសំណួរ ឬបញ្ជូនលំហាត់...'}
            className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

          {/* Send Button */}
          <button
            onClick={() => handleSendMessage()}
            disabled={!inputPrompt.trim() && !selectedImage}
            className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-bold transition-all shadow-xs active:scale-95"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
