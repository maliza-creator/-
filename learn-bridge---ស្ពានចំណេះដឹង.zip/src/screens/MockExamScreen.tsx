import React, { useState, useEffect } from 'react';
import { MockExam } from '../types';
import {
  ArrowLeft,
  Clock,
  Grid,
  Flag,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Send,
  Award,
} from 'lucide-react';

interface MockExamScreenProps {
  exam: MockExam;
  onBack: () => void;
  onFinishExam: (result: {
    score: number;
    total: number;
    percentage: number;
    grade: string;
    details: any[];
  }) => void;
}

export const MockExamScreen: React.FC<MockExamScreenProps> = ({
  exam,
  onBack,
  onFinishExam,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Record<number, boolean>>({});
  const [showMatrixModal, setShowMatrixModal] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(exam.durationMinutes * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const questionsList = exam?.questions || [];
  const currentQ = questionsList[currentIndex] || questionsList[0] || {
    id: 'default',
    questionKh: 'គ្មានសំណួរ',
    options: [],
    correctIndex: 0,
  };

  const handleSelectOption = (optIndex: number) => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentIndex]: optIndex,
    }));
  };

  const toggleFlag = () => {
    setFlaggedQuestions((prev) => ({
      ...prev,
      [currentIndex]: !prev[currentIndex],
    }));
  };

  const handleSubmitExam = () => {
    let score = 0;
    const details = questionsList.map((q, idx) => {
      const selected = userAnswers[idx];
      const isCorrect = selected === q.correctIndex;
      if (isCorrect) score += 1;
      return {
        questionId: q.id,
        questionKh: q.questionKh,
        selectedOption: selected,
        correctIndex: q.correctIndex,
        isCorrect,
      };
    });

    const totalQuestions = questionsList.length || 1;
    const pct = Math.round((score / totalQuestions) * 100);
    let grade = 'និទ្ទេស A';
    if (pct < 90) grade = 'និទ្ទេស B';
    if (pct < 80) grade = 'និទ្ទេស C';
    if (pct < 70) grade = 'និទ្ទេស D';
    if (pct < 60) grade = 'និទ្ទេស E';
    if (pct < 50) grade = 'ធ្លាក់ (F)';

    onFinishExam({
      score,
      total: exam.questions.length,
      percentage: pct,
      grade,
      details,
    });
  };

  const formatTimer = (totalSecs: number) => {
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const answeredCount = Object.keys(userAnswers).length;

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in pb-16">
      {/* Top BACII Official Header */}
      <div className="bg-slate-900 text-white p-3.5 sticky top-0 z-20 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <span className="text-[11px] font-bold text-amber-300 bg-amber-400/20 px-2.5 py-0.5 rounded-full border border-amber-400/30">
            បាក់ឌុប ២០២៦ Simulation
          </span>

          <button
            onClick={() => setShowMatrixModal(true)}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center gap-1 text-xs font-bold px-2.5"
          >
            <Grid className="w-4 h-4" />
            <span>{answeredCount}/{questionsList.length}</span>
          </button>
        </div>

        {/* Title & Countdown Timer */}
        <div className="flex items-center justify-between pt-1 border-t border-white/10">
          <h1 className="text-xs font-bold truncate max-w-[200px]">
            {exam?.titleKh}
          </h1>

          <div
            className={`flex items-center gap-1.5 font-mono text-xs font-bold px-3 py-1 rounded-full ${
              secondsRemaining < 300
                ? 'bg-red-500/30 text-red-300 animate-pulse border border-red-500/50'
                : 'bg-white/10 text-emerald-300'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{formatTimer(secondsRemaining)}</span>
          </div>
        </div>
      </div>

      {/* Main Question view */}
      <div className="p-4 space-y-4 flex-1 overflow-y-auto">
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <span className="text-xs font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              សំណួរទី {currentIndex + 1} នៃ {questionsList.length}
            </span>

            <button
              onClick={toggleFlag}
              className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full border transition-all ${
                flaggedQuestions[currentIndex]
                  ? 'bg-orange-100 text-orange-800 border-orange-300'
                  : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Flag className={`w-3.5 h-3.5 ${flaggedQuestions[currentIndex] ? 'fill-orange-600' : ''}`} />
              <span>{flaggedQuestions[currentIndex] ? 'បានកត់ចំណាំ' : 'កត់ចំណាំសម្រាប់ពិនិត្យ'}</span>
            </button>
          </div>

          <h3 className="text-sm font-extrabold text-slate-900 leading-relaxed">
            {currentQ.questionKh}
          </h3>

          {/* Options */}
          <div className="space-y-2.5 pt-2">
            {(currentQ.options || []).map((opt, idx) => {
              const isSelected = userAnswers[currentIndex] === idx;
              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-3.5 rounded-2xl border-2 text-xs text-left font-medium transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-50 border-blue-600 text-blue-900 font-bold shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-800 hover:border-blue-300'
                  }`}
                >
                  <span>{opt}</span>
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center text-[10px] ${
                      isSelected
                        ? 'border-blue-600 bg-blue-600 text-white font-bold'
                        : 'border-slate-300 text-slate-400'
                    }`}
                  >
                    {String.fromCharCode(65 + idx)}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Sticky Action Controls */}
      <div className="p-4 bg-white border-t border-slate-200 sticky bottom-0 z-20 shadow-lg flex items-center gap-2">
        <button
          onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
          disabled={currentIndex === 0}
          className="py-3 px-4 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-800 text-xs font-bold rounded-2xl transition-all"
        >
          ថយក្រោយ
        </button>

        {currentIndex < exam.questions.length - 1 ? (
          <button
            onClick={() => setCurrentIndex((prev) => Math.min(exam.questions.length - 1, prev + 1))}
            className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-md transition-all active:scale-98"
          >
            សំណួរដកបន្ទាប់ →
          </button>
        ) : (
          <button
            onClick={() => setShowSubmitConfirm(true)}
            className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-2xl shadow-md flex items-center justify-center gap-1.5 transition-all active:scale-98"
          >
            <Send className="w-4 h-4" />
            <span>ប្រគល់វិញ្ញាសា (Submit BACII)</span>
          </button>
        )}
      </div>

      {/* Question Navigator Drawer Modal */}
      {showMatrixModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <Grid className="w-4 h-4 text-blue-600" />
                កាតរៀបចំសំណួរវិញ្ញាសា
              </h3>
              <button
                onClick={() => setShowMatrixModal(false)}
                className="text-xs font-bold text-slate-400 hover:text-slate-600"
              >
                បិទ
              </button>
            </div>

            <div className="grid grid-cols-5 gap-2 max-h-60 overflow-y-auto">
              {questionsList.map((_, idx) => {
                const isAnswered = userAnswers[idx] !== undefined;
                const isFlagged = flaggedQuestions[idx];
                const isCurrent = idx === currentIndex;

                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setCurrentIndex(idx);
                      setShowMatrixModal(false);
                    }}
                    className={`h-10 rounded-xl font-bold text-xs flex flex-col items-center justify-center border relative transition-all ${
                      isCurrent
                        ? 'ring-2 ring-blue-600 border-blue-600 bg-blue-50 text-blue-900'
                        : isAnswered
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-900'
                        : 'bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span>{idx + 1}</span>
                    {isFlagged && (
                      <span className="w-2 h-2 rounded-full bg-orange-500 absolute top-1 right-1" />
                    )}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                setShowMatrixModal(false);
                setShowSubmitConfirm(true);
              }}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              ប្រគល់វិញ្ញាសាភ្លាមៗ
            </button>
          </div>
        </div>
      )}

      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-extrabold text-slate-900 text-base">
                តើអ្នកប្រាកដជាចង់ប្រគល់វិញ្ញាសាមែនទេ?
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                អ្នកបានធ្វើបាន {answeredCount} សំណួរ នៃសំណួរទាំង {exam.questions.length}។
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setShowSubmitConfirm(false)}
                className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                ត្រឡប់ទៅធ្វើតេស្ត
              </button>

              <button
                onClick={() => {
                  setShowSubmitConfirm(false);
                  handleSubmitExam();
                }}
                className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm"
              >
                ប្រគល់វិញ្ញាសា
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
