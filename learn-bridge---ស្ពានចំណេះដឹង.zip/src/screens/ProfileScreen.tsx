import React, { useState } from 'react';
import { User } from '../types';
import {
  User as UserIcon,
  Award,
  BookOpen,
  Target,
  Flame,
  Settings,
  Shield,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  LogOut,
  ChevronRight,
  Edit2,
  X,
} from 'lucide-react';

interface ProfileScreenProps {
  currentUser: User;
  onUpdateUser: (user: User) => void;
  onLogout: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  currentUser,
  onUpdateUser,
  onLogout,
}) => {
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [editName, setEditName] = useState(currentUser.name);
  const [editSchool, setEditSchool] = useState(currentUser.school);
  const [editStream, setEditStream] = useState(currentUser.stream);

  const weeklyStudyHours = [
    { day: 'ចន្ទ', hours: 2.5 },
    { day: 'អង្គារ', hours: 3.0 },
    { day: 'ពុធ', hours: 1.8 },
    { day: 'ព្រហ', hours: 4.2 },
    { day: 'សុក្រ', hours: 3.5 },
    { day: 'សៅរ៍', hours: 5.0 },
    { day: 'អាទិត្យ', hours: 4.0 },
  ];

  const maxHours = 5.0;

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...currentUser,
      name: editName,
      school: editSchool,
      stream: editStream,
    });
    setShowSettingsModal(false);
  };

  return (
    <div className="flex-1 bg-slate-50 p-4 space-y-4 animate-fade-in pb-16">
      {/* Profile Header Card */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white rounded-3xl p-5 sm:p-6 shadow-xl shadow-blue-200/60 relative overflow-hidden">
        <div className="flex items-start justify-between relative z-10">
          <div className="flex items-center gap-3.5">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-14 h-14 rounded-2xl object-cover ring-4 ring-white/20 shadow-md"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base font-extrabold">{currentUser.name}</h1>
                <span className="text-[10px] bg-amber-400 text-slate-900 font-bold px-2 py-0.5 rounded-full">
                  {currentUser.role === 'student' ? 'សិស្សថ្នាក់ទី១២' : 'គ្រូបង្រៀន'}
                </span>
              </div>

              <p className="text-xs text-blue-100/90 mt-0.5">{currentUser.school}</p>

              <span className="inline-block mt-2 text-[10px] font-bold px-3 py-1 rounded-full bg-white/20 border border-white/25 backdrop-blur-md">
                {currentUser.stream === 'science' ? '🔬 ថ្នាក់វិទ្យាសាស្ត្រ' : '📚 ថ្នាក់វិទ្យាសង្គម'}
              </span>
            </div>
          </div>

          <button
            onClick={() => setShowSettingsModal(true)}
            className="p-2.5 rounded-2xl bg-white/15 hover:bg-white/25 text-white backdrop-blur-md transition-colors"
            title="ការកំណត់គណនី"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Streak Bar */}
        <div className="mt-4 bg-white/20 backdrop-blur-md p-3.5 rounded-2xl border border-white/20 flex items-center justify-between text-xs font-bold relative z-10">
          <div className="flex items-center gap-1.5 text-amber-300">
            <Flame className="w-4 h-4 fill-amber-300 text-orange-900" />
            <span>សិក្សាជាប់គ្នា {currentUser.streakDays} ថ្ងៃ (Streak)</span>
          </div>
          <span className="text-white font-medium">ពិន្ទុសរុប {currentUser.totalPoints} pts</span>
        </div>
      </div>

      {/* Analytics Overview Grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl border border-blue-100">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold block">មេរៀនបានបញ្ចប់</span>
            <span className="text-base font-extrabold text-slate-800">១២ / ៤៥</span>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-sm flex items-center gap-3">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-100">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold block">ភាពត្រឹមត្រូវតេស្ត</span>
            <span className="text-base font-extrabold text-slate-800">៨៨.៥%</span>
          </div>
        </div>
      </div>

      {/* Weekly Study Activity Chart */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-blue-600" />
            ម៉ោងសិក្សាប្រចាំសប្តាហ៍ (Weekly Hours)
          </h3>
          <span className="text-[10px] text-slate-400 font-semibold">សរុប ២៤ ម៉ោង</span>
        </div>

        {/* Bar Chart Visual */}
        <div className="flex items-end justify-between h-28 pt-4 border-b border-slate-100 px-2">
          {weeklyStudyHours.map((item, idx) => {
            const heightPct = (item.hours / maxHours) * 100;
            return (
              <div key={idx} className="flex flex-col items-center gap-1.5 group">
                <span className="text-[9px] font-bold text-slate-400 group-hover:text-blue-600">
                  {item.hours}h
                </span>
                <div className="w-6 bg-slate-100 h-20 rounded-t-lg relative flex items-end overflow-hidden">
                  <div
                    className="w-full bg-gradient-to-t from-blue-600 to-indigo-500 rounded-t-lg transition-all duration-500 group-hover:from-blue-700 group-hover:to-orange-500"
                    style={{ height: `${heightPct}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-500 font-bold">{item.day}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Strengths vs Weaknesses Analysis */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
          ការវិភាគសមត្ថភាព (Strengths & Weaknesses)
        </h3>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-emerald-50/70 p-3.5 rounded-2xl border border-emerald-200/80 space-y-1">
            <span className="text-[10px] font-extrabold text-emerald-800 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              ចំណុចខ្លាំង
            </span>
            <p className="text-[11px] text-emerald-950 font-medium leading-relaxed">
              • លីមីតនៃអនុគមន៍<br />• ដេរីវេ និងលក្ខណៈ<br />• ប្រវត្តិវិទ្យា
            </p>
          </div>

          <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200/80 space-y-1">
            <span className="text-[10px] font-extrabold text-amber-800 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
              ត្រូវពង្រឹងបន្ថែម
            </span>
            <p className="text-[11px] text-amber-950 font-medium leading-relaxed">
              • អាំងតេក្រាល<br />• ចំនួនកុំផ្លិច<br />• រូបវិទ្យាអគ្គិសនី
            </p>
          </div>
        </div>
      </div>

      {/* Badges Showcase */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm space-y-3">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
          <Award className="w-4 h-4 text-amber-500" />
          មេដាយសមិទ្ធផល (Achievements)
        </h3>

        <div className="grid grid-cols-3 gap-2">
          {(currentUser?.badges || []).map((badge, idx) => (
            <div
              key={idx}
              className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-center space-y-1 hover:border-blue-300 transition-all"
            >
              <div className="text-2xl">{badge.icon}</div>
              <h4 className="text-[11px] font-bold text-slate-800 leading-tight">
                {badge.titleKh}
              </h4>
            </div>
          ))}
        </div>
      </div>

      {/* Logout Action Button */}
      <button
        onClick={onLogout}
        className="w-full py-3 bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs rounded-2xl border border-red-200 flex items-center justify-center gap-2 transition-all active:scale-98"
      >
        <LogOut className="w-4 h-4" />
        <span>ចាកចេញពីគណនី (Logout)</span>
      </button>

      {/* Profile Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveSettings}
            className="bg-white rounded-3xl p-5 w-full max-w-xs shadow-2xl space-y-3"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-800 text-sm">កែប្រែព័ត៌មានគណនី</h3>
              <button type="button" onClick={() => setShowSettingsModal(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ឈ្មោះពេញ
              </label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ឈ្មោះវិទ្យាល័យ
              </label>
              <input
                type="text"
                value={editSchool}
                onChange={(e) => setEditSchool(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ថ្នាក់សិក្សា (Stream)
              </label>
              <select
                value={editStream}
                onChange={(e) => setEditStream(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="science">🔬 ថ្នាក់វិទ្យាសាស្ត្រ</option>
                <option value="social">📚 ថ្នាក់វិទ្យាសង្គម</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              រក្សាទុកការផ្លាស់ប្តូរ
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
