import React from 'react';
import { Award, RotateCcw, Share2, CheckCircle2, XCircle, ArrowLeft, Sparkles } from 'lucide-react';

interface QuizResultScreenProps {
  score: number;
  total: number;
  answersHistory: any[];
  onRetry: () => void;
  onBackToHome: () => void;
}

export const QuizResultScreen: React.FC<QuizResultScreenProps> = ({
  score,
  total,
  answersHistory = [],
  onRetry,
  onBackToHome,
}) => {
  const safeHistory = answersHistory || [];
  const percentage = total > 0 ? Math.round((score / total) * 100) : 0;

  const getGrade = (pct: number) => {
    if (pct >= 90) return { grade: 'និទ្ទេស A', color: 'text-amber-500', bg: 'bg-amber-50 border-amber-200' };
    if (pct >= 80) return { grade: 'និទ្ទេស B', color: 'text-blue-600', bg: 'bg-blue-50 border-blue-200' };
    if (pct >= 70) return { grade: 'និទ្ទេស C', color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-200' };
    if (pct >= 60) return { grade: 'និទ្ទេស D', color: 'text-orange-500', bg: 'bg-orange-50 border-orange-200' };
    return { grade: 'និទ្ទេស E', color: 'text-slate-600', bg: 'bg-slate-100 border-slate-200' };
  };

  const gradeInfo = getGrade(percentage);

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-[600px] animate-fade-in p-4 space-y-4 pb-16">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToHome}
          className="p-2 rounded-full text-slate-600 hover:bg-slate-200"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-sm font-extrabold text-slate-800">លទ្ធផលធ្វើតេស្តសាកល្បង</h1>
        <button className="p-2 rounded-full text-slate-600 hover:bg-slate-200">
          <Share2 className="w-5 h-5" />
        </button>
      </div>

      {/* Main Score Circular Badge */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-md text-center space-y-4 relative overflow-hidden">
        <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white mx-auto flex flex-col items-center justify-center shadow-lg shadow-blue-500/30 ring-8 ring-blue-50">
          <span className="text-3xl font-black">{percentage}%</span>
          <span className="text-[10px] font-bold text-blue-200">
            {score} / {total} ត្រូវ
          </span>
        </div>

        <div>
          <span className={`inline-block px-4 py-1.5 rounded-full text-sm font-extrabold border ${gradeInfo.bg} ${gradeInfo.color}`}>
            <Sparkles className="w-4 h-4 inline mr-1" />
            {gradeInfo.grade}
          </span>
          <h2 className="text-base font-extrabold text-slate-900 mt-2">
            {percentage >= 80 ? 'អបអរសាទរ! សមត្ថភាពល្អប្រសើរខ្លាំង!' : 'ព្យាយាមបន្ថែមទៀតដើម្បីទទួលបាននិទ្ទេស A!'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            ការខិតខំប្រឹងប្រែងធ្វើតេស្តជាទៀងទាត់ជាសោរឆ្ពោះទៅកាន់ជោគជ័យបាក់ឌុប!
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 pt-2">
          <div className="bg-emerald-50 p-3 rounded-2xl border border-emerald-200 text-center">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
            <span className="text-xs text-emerald-800 font-bold block">ឆ្លើយត្រូវ</span>
            <span className="text-lg font-black text-emerald-700">{score} សំណួរ</span>
          </div>

          <div className="bg-red-50 p-3 rounded-2xl border border-red-200 text-center">
            <XCircle className="w-5 h-5 text-red-500 mx-auto mb-1" />
            <span className="text-xs text-red-800 font-bold block">ឆ្លើយខុស</span>
            <span className="text-lg font-black text-red-700">{total - score} សំណួរ</span>
          </div>
        </div>
      </div>

      {/* Answer History Review */}
      <div className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
          <Award className="w-4 h-4 text-blue-600" />
          ពិនិត្យចម្លើយឡើងវិញ ({safeHistory.length})
        </h3>

        <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
          {safeHistory.map((ans, idx) => (
            <div
              key={idx}
              className={`p-3 rounded-2xl border text-xs flex items-center justify-between ${
                ans.isCorrect
                  ? 'bg-emerald-50/50 border-emerald-200 text-emerald-950'
                  : 'bg-red-50/50 border-red-200 text-red-950'
              }`}
            >
              <div className="flex items-center gap-2 max-w-[85%]">
                {ans.isCorrect ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-500 shrink-0" />
                )}
                <span className="font-bold truncate">
                  {idx + 1}. {ans.questionKh}
                </span>
              </div>
              <span className="font-bold text-[10px]">
                {ans.isCorrect ? 'ត្រឹមត្រូវ' : 'មិនត្រូវ'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Action Buttons */}
      <div className="grid grid-cols-2 gap-3 pt-2">
        <button
          onClick={onRetry}
          className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-95"
        >
          <RotateCcw className="w-4 h-4 text-slate-600" />
          <span>ធ្វើតេស្តម្តងទៀត</span>
        </button>

        <button
          onClick={onBackToHome}
          className="py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-95"
        >
          <span>ត្រឡប់ទៅទំព័រដើម</span>
        </button>
      </div>
    </div>
  );
};
