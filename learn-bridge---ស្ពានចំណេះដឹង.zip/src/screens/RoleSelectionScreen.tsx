import React from 'react';
import { UserCheck, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { UserRole } from '../types';

interface RoleSelectionScreenProps {
  onSelectRole: (role: UserRole) => void;
}

export const RoleSelectionScreen: React.FC<RoleSelectionScreenProps> = ({ onSelectRole }) => {
  return (
    <div className="flex-1 flex flex-col p-6 bg-slate-50 min-h-[600px]">
      {/* Header */}
      <div className="text-center mt-4 mb-8">
        <span className="text-xs font-bold text-blue-600 uppercase tracking-wider bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
          ជំហានទី ១ / ២
        </span>
        <h2 className="text-2xl font-extrabold text-slate-800 mt-3 mb-1">
          ជ្រើសរើសតួនាទីរបស់អ្នក
        </h2>
        <p className="text-xs text-slate-500">
          សូមជ្រើសរើសប្រភេទគណនីដើម្បីបន្តប្រើប្រាស់ Learn Bridge
        </p>
      </div>

      {/* Role Cards */}
      <div className="space-y-4 flex-1 my-auto max-w-sm mx-auto w-full">
        {/* Student Role Card */}
        <button
          onClick={() => onSelectRole('student')}
          className="w-full text-left bg-white p-5 rounded-3xl border-2 border-blue-100 hover:border-blue-500 shadow-sm hover:shadow-md transition-all group relative overflow-hidden active:scale-98"
        >
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors shadow-xs">
              <UserCheck className="w-6 h-6" />
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 text-base group-hover:text-blue-600 transition-colors">
                  ខ្ញុំជាសិស្ស (Student)
                </h3>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-600 transition-transform group-hover:translate-x-1" />
              </div>
              <p className="text-xs text-slate-500 mt-1">
                ត្រៀមប្រឡងបាក់ឌុបថ្នាក់ទី១២
              </p>

              <ul className="mt-3 space-y-1.5 text-[11px] text-slate-600">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                  រៀនមេរៀន ធ្វើលំហាត់ & តេស្តសាកល្បង
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                  សួរដេញដោលជាមួយ BridgeBot AI Tutor
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
                  ចូលរួម ឬបង្កើតក្លឹបសិក្សាជាមួយមិត្តភក្តិ
                </li>
              </ul>
            </div>
          </div>
        </button>

        {/* Teacher Role Card */}
        <button
          onClick={() => onSelectRole('teacher')}
          className="w-full text-left bg-white p-5 rounded-3xl border-2 border-orange-100 hover:border-orange-500 shadow-sm hover:shadow-md transition-all group relative overflow-hidden active:scale-98"
        >
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center group-hover:bg-orange-600 group-hover:text-white transition-colors shadow-xs">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 text-base group-hover:text-orange-600 transition-colors">
                  ខ្ញុំជាគ្រូបង្រៀន (Teacher)
                </h3>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-orange-600 transition-transform group-hover:translate-x-1" />
              </div>
              <p className="text-xs text-slate-500 mt-1">
                ចែករំលែកចំណេះដឹង & គ្រប់គ្រងការសិក្សា
              </p>

              <ul className="mt-3 space-y-1.5 text-[11px] text-slate-600">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-orange-500" />
                  បង្កើតមេរៀន លំហាត់ & វិញ្ញាសាបាក់ឌុប
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-orange-500" />
                  គ្រប់គ្រងក្លឹបសិក្សា & បង្ហោះការជូនដំណឹង
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-orange-500" />
                  តាមដានស្ថិតិ និងលទ្ធផលសិក្សារបស់សិស្ស
                </li>
              </ul>
            </div>
          </div>
        </button>
      </div>

      {/* Footer */}
      <p className="text-center text-[11px] text-slate-400 mt-6">
        អ្នកអាចប្តូរតួនាទីឡើងវិញបានគ្រប់ពេលនៅក្នុង Settings
      </p>
    </div>
  );
};
