import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Gemini SDK lazily / safely
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// API Routes
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', app: 'Learn Bridge Khmer Educational Platform' });
});

app.post('/api/ai-tutor', async (req, res) => {
  try {
    const { prompt, subject, imageBase64 } = req.body;
    if (!prompt && !imageBase64) {
      return res.status(400).json({ error: 'Prompt or image is required' });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Intelligent Khmer response fallback if API key is not attached yet
      return res.json({
        reply: `សួស្ដី! ខ្ញុំជា **BridgeBot AI** គ្រូបង្រៀនជំនួយការប្រឡងបាក់ឌុប (Grade 12 BACII)។\n\nទាក់ទងនឹងសំណួររបស់អ្នកអំពី "${prompt || 'រូបភាពសំណួរ'}"៖\n\n១. **គោលការណ៍គ្រឹះ**៖ ក្នុងការប្រឡងបាក់ឌុបថ្នាក់ទី១២ ចំណុចនេះទាមទារឱ្យសិស្សយល់ច្បាស់ពីរូបមន្ត និងជំហានដោះស្រាយ។\n\n២. **ដំណោះស្រាយគំរូ**៖\n- **ជំហានទី១**៖ ពិនិត្យមើលលក្ខខណ្ឌដើមនៃលំហាត់\n- **ជំហានទី២**៖ ជំនួសតម្លៃ ឬប្រើរូបមន្តសម្រួល\n- **ជំហានទី៣**៖ ផ្ទៀងផ្ទាត់ចម្លើយចុងក្រោយ\n\n💡 **គន្លឹះប្រឡងបាក់ឌុប**៖ ខិតខំសរសេរឱ្យមានរបៀបរៀបរយ និងបង្ហាញជំហានគណនាឱ្យបានច្បាស់លាស់ដើម្បីទទួលបានពិន្ទុពេញ!`,
      });
    }

    const systemInstruction = `You are "BridgeBot AI", a friendly, highly knowledgeable, encouraging Khmer educational AI tutor designed for Cambodian Grade 12 students preparing for the BACII (បាក់ឌុប) national examination.
Subject area context: ${subject || 'Grade 12 BACII Preparation'}.
You explain concepts clearly in modern natural Khmer language (ភាសាខ្មែរ), providing step-by-step mathematical/scientific derivations, formulas, examples, literature summaries, and Grade A exam strategies.
Use clean markdown formatting with bolding, bullet points, and step-by-step listings. Always be encouraging, structured, and helpful.`;

    let contents: any;
    if (imageBase64) {
      const mimeType = imageBase64.startsWith('data:image/jpeg') ? 'image/jpeg' : 'image/png';
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      contents = {
        parts: [
          { inlineData: { mimeType, data: cleanBase64 } },
          { text: prompt || 'សូមជួយដោះស្រាយលំហាត់ក្នុងរូបភាពនេះ និងពន្យល់ជំហាននីមួយៗឱ្យបានច្បាស់លាស់ក្នុងភាសាខ្មែរ។' },
        ],
      };
    } else {
      contents = prompt;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({ reply: response.text || 'សុំទោស មិនមានចម្លើយឆ្លើយតប។' });
  } catch (error: any) {
    console.error('Error calling Gemini AI Tutor:', error);
    res.status(500).json({
      error: 'Failed to generate response',
      message: error.message || 'Error processing query',
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
